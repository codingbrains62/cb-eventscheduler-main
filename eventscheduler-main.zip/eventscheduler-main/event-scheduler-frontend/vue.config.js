module.exports = {   
    devServer: {     
        proxy: {
            '^/api/': {
                target: 'http://localhost:1337',
                pathRewrite: { "^/api/": "/" },
                changeOrigin: true,
                ws: true,
                logLevel: "debug"
            },
           '/api2': {
                
                target: 'https://clasinfopro.clasinfo.com',
                pathRewrite: { "^/api2/": "" },
                changeOrigin: true,
                ws: true,
                logLevel: "debug"
            },         
                
        },
        allowedHosts: [
            'eventscheduler.clastechservices.com',
            '*.clastechservices.com',
            '*.clasinfo.com',
        ]
    } 
}