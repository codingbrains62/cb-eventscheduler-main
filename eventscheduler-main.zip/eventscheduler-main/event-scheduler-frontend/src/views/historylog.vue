<template>
  
    <historylog/>
  
</template>

<script>
// @ is an alias to /src
import historylog from '../components/historylog.vue'



export default {
  components: {
    historylog
  }
}
</script>
