<template>
    <div >
       <div class="card" align="center" style="margin: .5rem;padding: 1rem;">
        <b-table striped  :fields="fields" :items="filtered" >
              <template slot="top-row" slot-scope="{ fields }">
                <td v-for="field in fields" :key="field.key">
                  <input v-model="filters[field.key]" :placeholder="filterText(field.label)" v-if="field.filter" style="width:115px;">
                </td>
              </template>
           
            <template v-slot:cell(Actions)="row">
              <b-button @click="ClickShowDownloaded(row.item.serviceindex)" v-b-tooltip.hover title="Show documents" variant="outline-primary" class="btn btn-sm m-2"> <b-icon icon="filter-square"></b-icon></b-button>
              <b-button @click="ClickShowInvoices(row.item.serviceindex)" v-b-tooltip.hover title="Show Invoice" variant="outline-success" class="btn btn-sm m-2"><b-icon icon="filter-square"></b-icon>
              </b-button>
            </template>
          </b-table>
        </div>
        <div >
          <b-modal  v-model="modalDocs" size="lg" title="My Documents" hide-footer>
            <label v-if="arrDocs.length === 0">There are no documents; please contact service.</label>    
              <b-table striped selectable select-mode="single" @row-selected="onRowSelected" sticky-header="83vh" :fields="documentfields" :items="arrDocs" class="historicalSearchesGrid" v-if="arrDocs.length > 0">                 
                  <template v-slot:cell(JobDocumentIndex)="row">
                      <b-button @click="ClickShowDocument(row.item)" v-b-tooltip.hover title="View document" variant="outline-primary" class="btn btn-sm m-2"><b-icon icon="filter-square"></b-icon></b-button>
                  </template>                       
              </b-table>
            <label>Questions? Contact us for assistance at (800) 952-5696 or connect@clasinfo.com</label><br>
          <b-button  class="mt-3" variant="outline-warning" block @click="hideInvoiceModal">Close</b-button>
        </b-modal>
           <b-modal v-model="modalInvoices" size="lg" title="My Invoices" hide-footer>
            <label v-if="arrInvoices.length === 0">There are no invoices; please contact service.</label>    
              <b-table striped selectable select-mode="single" @row-selected="onRowSelected" sticky-header="83vh" :fields="invoicefields" :items="arrInvoices" class="historicalSearchesGrid" v-if="arrInvoices.length > 0">                  
                  <template v-slot:cell(InvoiceIndex)="row">
                      <b-button @click="ClickShowInvoice(row.item)" v-b-tooltip.hover title="View invoice" variant="outline-primary" class="btn btn-sm m-2" ><b-icon icon="filter-square"></b-icon></b-button>
                  </template>                       
              </b-table>
            <label>Questions? Contact us for assistance at (800) 952-5696 or connect@clasinfo.com</label>
            <br>
          <b-button class="mt-3" variant="outline-warning" block @click="hideInvoiceModal">Close</b-button>
        </b-modal>
        </div>
        <p style="text-align: center;"><br>CLAS offers free training for all of our online solutions, If you would like to schedule a training session either individually or for a group at your organization, please contact us at (800) 952-5696 or by email at <a href="mailto:connect@clasinfo.com">connect@clasinfo.com</a>.</p>
        <br>  
      <div style="text-align: center;" class="footer">CLAS Information Services &#169; 2021   |       <a href="https://www.clasinfo.com/index.php/disclaimer/">Disclaimer</a>|<a href="https://www.clasinfo.com/index.php/terms-of-use/">Terms of Use</a>
      </div>
      </div>
</template>
<script>
  import axios from 'axios'
export default {
 data: function (){
     return { 
   
     modalInvoices: false,
     modalDocs: false,
     selected: [],
     arrInvoices: [], 
     arrDocs: [],  
     thedata: [],  
       fields: [
          {
            key: 'clientfullname',
            label: 'full name',
            sortable: true,
            filter: true,
           // thStyle: {width: '125px !important'},    
          },
          {
            key: 'jobnumber',
            label: 'job number',
            sortable: true,
            filter: true,
           // thStyle: {width: '125px !important'},    
          },
          {
            key: 'jurisdiction',
            label: 'jurisdiction',
            sortable: true,
            filter: true,
           // thStyle: {width: '125px !important'},            
          },
          {
            key: 'entityname',
            label: 'entity name',
            sortable: true,
            filter: true
          },
          {
            key: 'servicename',
            label: 'service name',
            sortable: true,
            filter: true
          },
          {
            key: 'clientreference',
            label: 'Reference',
            sortable: true,
            filter: true
          }, 
          {
            key: 'clientservicecurrentstatus',
            label: 'Status',
            sortable: true,
            filter: true
          },          
          {
            key: 'Actions',
            label: 'Actions',
            sortable: false,
            filter: false
          },          
        ],
        filters: {
          jobnumber: '',
          jurisdiction: '',
          entityname: '',
          clientreference: '',
          clientservicecurrentstatus: ''
        },
        
        invoicefields: [ 
            {
              key: 'InvoiceNumber',
              label: 'Invoice Number',
              sortable: true
            },
            {
              key: 'InvoiceTotal',
              label: 'Invoice Total',
              formatter: 'formatAssigned',
              sortable: true
            },
            {
              key: 'InvoiceDate',
              label: 'Invoice Date',
              sortable: true
            }, 
            {
              key: 'InvoiceIndex',
              label: 'Invoice',
              sortable: false
            },                                   
        ],
        
        documentfields: [ 
            {
              key: 'JobDocumentName',
              label: 'Document Name',
              //sortable: true
            },
            {
              key: 'CreatedDate',
              label: 'Create Date',
              ///sortable: true
            },
            {
              key: 'JobDocumentType',
              label: 'Document Type',
              //sortable: true
            }, 
            {
              key: 'JobDocumentIndex',
              label: 'Document',
              //sortable: false
            },              
        ],    
   }
    },
    computed: {
      filtered () {
        const filtered = this.thedata.filter(item => {
          return Object.keys(this.filters).every(key =>
              String(item[key]).toUpperCase().includes(this.filters[key].toUpperCase()))
        })
        return filtered.length > 0 ? filtered : [{
          jobnumber: '',
          jurisdiction: '',
          entityname: '',
          clientreference: '',
          clientservicecurrentstatus: ''
        }]
      }
    },
      beforeMount: async function() {
  
      },
      mounted: async function(){
        this.getclasinfo() ;
      },
      beforeDestroy: function() {
        
      },    
      methods: {
        ClickShowDocument: async function(item) {  
              this.viewDoc(item.JobDocumentIndex);
            }, 
            ClickShowInvoice: async function(item) {  
              this.viewInvoice(item.InvoiceIndex);
            },  
        onRowSelected(items) {
          console.log(items)
              ///this.selected = items
          },
        filterText: function(strText) {
            return 'Filter by '+strText;
          },
          ClickShowServiceResults: async function(itemid) {
            alert('Results! = '+itemid)
          },
          ClickShowDownloaded: async function(itemid) {
           
            this.getDocs(itemid)
            this.modalDocs = true;
          },
          ClickShowInvoices: async function(itemid) {
           
            this.getInvoices(itemid)
            this.modalInvoices = true;
          },
          hidemodalDocs() {
            this.modalInvoices = false;  
        },
        hideInvoiceModal() {
          this.modalDocs = false;  
          this.modalInvoices = false; 
        },
        viewInvoice: async function(intInvoiceIndex){
        
          try {
            ///intInvoiceIndex=101010;
            var urlp = '';//  http://clasinfo.clastechservices.com/swfs/maincontainer_liveserver.html
                  urlp = urlp + '/api2/ColdFusion/invoicereportbyindex.cfm?intInvoiceIndex='+intInvoiceIndex   
                  var response = await axios.get(urlp);
                  
            var pdfWindow = window.open(urlp, '_blank');    
             
        } catch (error) {
            
            console.error(error);
            
        }
          
      },  
      viewDoc: async function(intDocIndex){
        
          try {
            var urlp = '';//  http://clasinfo.clastechservices.com/swfs/maincontainer_liveserver.html
                  urlp = urlp + '/api2/ColdFusion/JobDocGetDoc.cfm?JobDocIndex='+intDocIndex   
                  var response = await axios.get(urlp);
                  
            var pdfWindow = window.open(urlp, '_blank');    
             
        } catch (error) {
            
            console.error(error);
            
        }
          
      },    
        getInvoices: async function(intInvoice){           
            
            try {
/*
              axios.post('/api/get-invoice',{id:intInvoice              
                    }).then((response) => {
                      ///console.log(response)
                        if(response.data.status_code==200){
                          if(response.data.message!==undefined){
                            this.arrInvoices=response.data.message;

                          }
                        }else if(response.data.record.status_code==500){
                            this.$toast.success({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                            this.$toast.error({message:response.data.record.message})
                            localStorage.clear();
                            location.replace("/");
                                
                        }
                        else if(response.data.status_code==202){
                            this.$toast.success({message:response.data.message})
                                
                        }
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    }); */
                          
                var url = '';
                url = url + '/api2/ColdFusion/Invoicing.cfc'
                url = url + '?method=GetInvoiceByServiceIndex'
                url = url + '&intSearchIndex='+intInvoice;
                var response = await axios.get(url);  
            console.log(response.data); 
            /// sample response  <wddxPacket version='1.0'><header/><data><number>291230.0</number></data></wddxPacket>
           
                var startLoc = response.data.indexOf("<string>");            
                
                if(startLoc == -1){
               // This means no Invoices yet
              }else{  
                var startLoc = response.data.indexOf("<string>");             
                  var endLoc  = response.data.indexOf("</string>");
                  var TheValue = response.data.slice(startLoc+8,endLoc );   
                  var objParse = JSON.parse(TheValue);
      
                  this.arrInvoices = [];                
                  for (let index = 0; index < objParse.DATA.length; index++) {  // DATA  --> "COLUMNS":["INVOICEINDEX","INVOICESTATUS","INVOICENUMBERGROUP","INVOICENUMBER","PREPAYMENTAPPLICATIONINDEX","DISCOUNTINDEX","CREATEDDATE","CREATEDBY","MODIFIEDDATE","MODIFIEDBY","STAFFFULLNAME","INVOICETOTAL"]
                      const element = objParse.DATA[index];
                      var objTemp = {};
                      objTemp.InvoiceIndex = element[0];
                      objTemp.InvoiceNumber = element[2];
                      objTemp.InvoiceDate = element[6];
                      objTemp.InvoiceTotal = parseFloat(element[11]);
                      this.arrInvoices.push(objTemp);
                  }               
                  console.log(this.arrInvoices);
            }
          } catch (error) {
            
            console.error(error);
            
          }
            
      },
      getclasinfo:async function()
      {
        try{
            var websitelinkid=localStorage.getItem('websitelinkid');
            var bookkeepingid=localStorage.getItem('bookkeepingid');
            axios.post('/api/clasinfo',{websitelinkid:websitelinkid,bookkeepingid:bookkeepingid              
                    }).then((response) => {
                      console.log(response)
                        if(response.data.status_code==200){
                           this.thedata=response.data.message;
                        }else if(response.data.record.status_code==500){
                            this.$toast.success({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                           this.$toast.error({message:response.data.record.message})
                          localStorage.clear();
                            location.replace("/");
                                
                        }
                        else if(response.data.status_code==202){
                            this.$toast.success({message:response.data.message})
                                
                        }
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });

        }catch(error){
           console.error(error);
        }
      }
      ,
      getDocs: async function(intDocNum){          
            
            try {
              /* var url = '';
                url = url + '/api2/ColdFusion/Invoicing.cfc'
                url = url + '?method=GetInvoiceByServiceIndex'
                url = url + '&intSearchIndex='+intDocNum;*/
                  //console.log(url);
                    /*axios.post('/api/get-document',{id:intDocNum              
                    }).then((response) => {
                      console.log(url)
                        if(response.data.status_code==200){
                          if(response.data.message!==undefined){
                            this.arrDocs= response.data.message;

                          }
                        }else if(response.data.record.status_code==500){
                            this.$toast.success({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                            this.$toast.error({message:response.data.record.message})
                            localStorage.clear();
                            location.replace("/");
                                
                        }
                        else if(response.data.status_code==202){
                            this.$toast.success({message:response.data.message})
                                
                        }
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });   */    
                var url = '';
                url = url + '/api2/ColdFusion/Utilities.cfc'
                url = url + '?method=GetDocuments2New'
                url = url + '&intServiceIndices='+intDocNum;
                var response = await axios.get(url);  
            console.log(response.data); /// sample response  <wddxPacket version='1.0'><header/><data><number>291230.0</number></data></wddxPacket>
           
                var startLoc = response.data.indexOf("<string>");            
                
                if(startLoc == -1){
               // This means no Invoices yet
              }else{  
                var startLoc = response.data.indexOf("<string>");             
                  var endLoc  = response.data.indexOf("</string>");
                  var TheValue = response.data.slice(startLoc+8,endLoc );   
                  var objParse = JSON.parse(TheValue);
      
                  this.arrDocs = [];                
                  for (let index = 0; index < objParse.DATA.length; index++) {  // DATA  --> "COLUMNS":["INVOICEINDEX","INVOICESTATUS","INVOICENUMBERGROUP","INVOICENUMBER","PREPAYMENTAPPLICATIONINDEX","DISCOUNTINDEX","CREATEDDATE","CREATEDBY","MODIFIEDDATE","MODIFIEDBY","STAFFFULLNAME","INVOICETOTAL"]
                      const element = objParse.DATA[index];
                      var objTemp = {};
                      objTemp.JobServiceIndex = element[0];
                      objTemp.JobDocumentIndex = element[1];
                      objTemp.JobDocumentName = element[2];
                      objTemp.CreatedDate = element[3];
                      objTemp.JobDocumentType = element[4];
                      this.arrDocs.push(objTemp);
                  }               
                  console.log(this.arrDocs);
            }
          } catch (error) {
            
            console.error(error);
            
          }
            
      }
    }  
  }
    
    
    

 
 
</script>

