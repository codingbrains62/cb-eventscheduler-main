<template>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-3">
                <edituser/>
            </div>
           
        </div>
    </div>
</template>
<script>
import edituser from '../components/edituser.vue'


export default({
    components: {
      edituser
    
  }
})
</script>
