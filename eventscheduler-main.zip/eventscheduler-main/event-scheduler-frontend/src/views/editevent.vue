<template>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-3">
                <editevent/>
            </div>
           
        </div>
    </div>
</template>
<script>
import editevent from '../components/editevent.vue'


export default({
    components: {
      editevent
    
  }
})
</script>
