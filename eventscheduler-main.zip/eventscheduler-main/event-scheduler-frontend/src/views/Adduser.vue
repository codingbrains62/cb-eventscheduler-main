<template>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-3">
                <adduser/>
            </div>
           
        </div>
    </div>
</template>
<script>
import adduser from '../components/adduser.vue'


export default({
    components: {
      adduser
    
  }
})
</script>
