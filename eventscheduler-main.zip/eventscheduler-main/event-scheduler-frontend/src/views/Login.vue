<template>
  <div>
    <ciplogin/>
  </div>
</template>

<script>
// @ is an alias to /src
import ciplogin from '../components/ciplogin.vue'



export default {
  components: {
    ciplogin
  }
}
</script>
