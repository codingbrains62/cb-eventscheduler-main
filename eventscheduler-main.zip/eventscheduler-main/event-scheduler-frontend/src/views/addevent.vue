<template>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-3">
                <addevent />
            </div>
           
        </div>
    </div>
</template>
<script>
import addevent from '../components/addevent.vue'


export default({
    components: {
      addevent
    
  }
})
</script>
