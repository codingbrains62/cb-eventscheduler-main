<template>
    <div class="container">
        <div class="innersection dashboard">
            <div class="row">
                <div class="col-md-12">
                    <!-- <h1 class="heading">Welcome Back, {{ fullname }}!</h1> -->
                    <h1 class="heading">Scheduled Events</h1>
                    <p class="text-center">Schedule tasks can create static web pages from dynamic data sources. You can also schedule tasks to update Solr searches and to create reports. </p>
                </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                   <div class="schedule_new_task">
                       <a href="/addevent" class="btn btn_sechedule_new_task"> Schedule New Event</a>
                       <h4 class="scheduled_task">Server Level Scheduled Events</h4>
                       <div class="table-responsive">
                         <b-table striped hover :items="items" :fields="fields">

                            <template v-slot:cell(event_status)="row">
                              <b-icon v-if="!row.item.event_status"  v-b-tooltip.hover title="Paused" class="btn btn-sm m-2 rounded-circle" icon="exclamation-circle-fill" variant="warning"></b-icon>
                              <b-icon v-if="row.item.event_status" class="btn btn-sm m-2 rounded-circle" icon="exclamation-circle-fill" variant="success"></b-icon>
                            </template>

                            <template v-slot:cell(Actions)="row">
                              <b-button @click="ClickToRun(row.item.id)" v-b-tooltip.hover title="Run Now" variant="outline-dark" class="btn btn-sm m-2 rounded-circle"> <b-icon icon="caret-right-fill"></b-icon>
                              </b-button>
                              <b-button @click="ClickToResume(row.item.id)" v-b-tooltip.hover title="Resume" variant="outline-primary" class="btn btn-sm m-2 rounded-circle"> <b-icon icon="caret-right-fill"></b-icon>
                              </b-button>
                              <b-button @click="ClickToPause(row.item.id)" v-b-tooltip.hover title="Pause" variant="outline-success" class="btn btn-sm m-2 rounded-circle"><b-icon icon="pause"></b-icon>
                              </b-button>
                               <b-button @click="ClickToEdit(row.item.id)" v-b-tooltip.hover title="Edit" variant="outline-success" class="btn btn-sm m-2 rounded-circle"><b-icon icon="pen"></b-icon>
                              </b-button>
                               <b-button @click="ClickToRemove(row.item.id)" v-b-tooltip.hover title="Remove" variant="outline-danger" class="btn btn-sm m-2 rounded-circle"><b-icon icon="x"></b-icon>
                              </b-button>
                            </template>

                         </b-table>
                        </div>
                   </div>
               </div>
              
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios'

export default {
    data(){
       return {
       fields: [
          {
            key: 'event_status',
            label: 'Event Status',
            sortable: false,
            filter: false
          },
          {
            key: 'Actions',
            label: 'Actions',
            sortable: false,
            filter: false    
          },
          {
            key: 'group',
            label: 'Group',
            sortable: false,
            filter: false
          },            
            {
            key: 'event_name',
            label: 'Event Name',
            sortable: false,
            filter: false
            },
            {
            key: 'duration',
            label: 'Duration',
            sortable: false,
            filter: false
            } ,
            {
            key: 'interval',
            label: 'interval',
            sortable: false,
            filter: false
            } ,
            {
            key: 'last_run',
            label: 'Last Run',
            sortable: false,
            filter: false
            } ,
            {
            key: 'next_run',
            label: 'Next Run',
            sortable: false,
            filter: false
            } ,
            {
            key: 'repeat',
            label: 'Repeat',
            sortable: false,
            filter: false
            } ,
            {
            key: 'remaining_count',
            label: 'Remaining count',
            sortable: false,
            filter: false
            } ,


                   
        ],
        items: [],
      }
    },
    created () {
      this.pollData()

    },
    mounted(){
       this.EventList();
       
    },
    methods:{
        async pollData(){
       setInterval(function () {  this.EventList(); 
       }.bind(this), (2*60000))
        },
        async EventList(){

      
              axios.get('/api/view-event', {
               
            }).then((response) => {
                if(response.data.record.status_code == 200){
                    this.items=response.data.record.message;
                }
                else if(response.data.record.status_code == 202){
                     this.$toast.error({message:response.data.record.message});
                }
                else if(response.data.record.status_code==403){
                      this.$toast.error({message:response.data.record.message})
                        localStorage.clear();
                        location.replace("/");
                }
                else if(response.data.record.status_code==500){
                      this.$toast.error({message:response.data.record.message})
                        
                }
            },(error) => {
                console.log(error);
            });
       
        },
        async ClickToRemove(item){
            if(confirm("Are You Sure Remove This User "))
                    {
                       axios.post('/api/remove-event',{id:item               
                             }).then((response) => {
                        if(response.data.record.status_code==200){
                             this.$toast.success({message:response.data.record.message});
                        //localStorage.setItem('lastSegment',0)
                             this.EventList();
                        }else if(response.data.record.status_code==202){
                              this.$toast.error({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==500){
                              this.$toast.error({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                              this.$toast.error({message:response.data.record.message})
                                localStorage.clear();
                                location.replace("/");
                        }
                        
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });
                    }
        },
        ClickToEdit:function (item) {
          localStorage.setItem('eventId',item);
           location.replace("/editevent");
        },
        ClickToPause:function(item){
            axios.post('/api/pause-event',{id:item               
                             }).then((response) => {
                        if(response.data.record.status_code==200){
                             this.$toast.success({message:response.data.record.message});
                        //localStorage.setItem('lastSegment',0)
                             this.EventList();
                        }
                        else if(response.data.record.status_code==500){
                              this.$toast.error({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                              this.$toast.error({message:response.data.record.message})
                                localStorage.clear();
                                location.replace("/");
                        }
                        
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });

        },
        ClickToResume:function(item){
             axios.post('/api/resume-event',{id:item               
                             }).then((response) => {
                        if(response.data.record.status_code==200){
                             this.$toast.success({message:response.data.record.message});
                        //localStorage.setItem('lastSegment',0)
                             this.EventList();
                        }
                        else if(response.data.record.status_code==500){
                              this.$toast.error({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                              this.$toast.error({message:response.data.record.message})
                                localStorage.clear();
                                location.replace("/");
                        }
                        
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });
        },
        ClickToRun:function(item){
             axios.post('/api/run-event',{id:item               
                             }).then((response) => {
                        if(response.data.record.status_code==200){
                             this.$toast.success({message:response.data.record.message});
                        //localStorage.setItem('lastSegment',0)
                             this.EventList();
                        }
                        else if(response.data.record.status_code==500){
                              this.$toast.error({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                              this.$toast.error({message:response.data.record.message})
                                localStorage.clear();
                                location.replace("/");
                        }
                        
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });
        },
    }
}
</script>