import Vue from 'vue'
import App from './App.vue'
import './assets/css/cipmain.css';

import { BootstrapVue, IconsPlugin } from 'bootstrap-vue'

// Import Bootstrap an BootstrapVue CSS files (order is important)
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import 'cxlt-vue2-toastr/dist/css/cxlt-vue2-toastr.css'
import cors from 'cors'
import router from './router'

import Vuelidate from 'vuelidate'
import VueCookies from 'vue-cookies'
Vue.use(VueCookies)
Vue.use(Vuelidate)
// Make BootstrapVue available throughout your project
Vue.use(BootstrapVue)
// Optionally install the BootstrapVue icon components plugin
Vue.use(IconsPlugin)
import CxltToastr from 'cxlt-vue2-toastr'
var toastrConfigs = {
    position: 'top right',
    showDuration: 2000
}
import { library } from '@fortawesome/fontawesome-svg-core'
import { faCoffee } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'

library.add(faCoffee)

Vue.component('font-awesome-icon', FontAwesomeIcon)
Vue.use(CxltToastr, toastrConfigs)
Vue.use(cors)

Vue.config.productionTip = false



new Vue({
  router,
  render: h => h(App)
}).$mount('#app')

