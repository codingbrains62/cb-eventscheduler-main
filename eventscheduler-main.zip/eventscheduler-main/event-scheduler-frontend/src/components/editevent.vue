<template>
    <div class="usermain">
       <div class="row">
                <b-form id="form" @submit.prevent="UpdateEvent"    @reset.prevent="ResetEvent">
                   <div class="col-md-12">
                        
                         
                        <b-card bg-variant="light">
                            <h2>Edit Scheduled Event </h2>
                            <div class="secbrder">
                            <b-form-group
                                label="Event Name"
                                label-for="user-name"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-name" v-model="event_name" type="text" placeholder="Event Name" ></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label="Group Name"
                                label-for="group-name"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="group-name" v-model="group_name" type="text" placeholder="Group Name" ></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label="Duration"
                                label-cols-sm="2"
                                label-align-sm="right"
                               
                            >
                            <div class="row">
                            <div class="col-sm-6">
                                  <label>Start Date</label>
                            <!--    <b-form-input id="start_date" type="text" v-model="start_date"  ></b-form-input> -->  
                               <b-form-datepicker
                                  id="datepicker-dateformat2"
                                  :date-format-options="{ year: 'numeric', month: 'numeric', day: 'numeric' }"
                                  locale="en"
                                  v-model="start_date"
                                ></b-form-datepicker>

                            </div>
                            <div class="col-sm-6">
                                  <label>End Date</label>
                               <!-- <b-form-input id="end_date" type="text" v-model="end_date"  ></b-form-input> -->
                               <b-form-datepicker
                                  id="datepicker-dateformat3"
                                  :date-format-options="{ year: 'numeric', month: 'numeric', day: 'numeric' }"
                                  locale="en"
                                  v-model="end_date"
                                ></b-form-datepicker>
                                
                            </div>
                            </div>
                             
                            </b-form-group>

                            <b-form-group
                                label="Frequency"
                                label-for="user-company"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                              <div class="row frequency">
                            <b-form-radio 
                                 v-model="selected" 
                                
                                 name="some-radios" 
                                 class="col-sm-4 one_at_a_time"
                                 value="one_at_time">One-Time at 
                             </b-form-radio>
                             <div class="col-sm-4">
                                <b-form-timepicker v-model="one_at_time" locale="en"></b-form-timepicker>
                              <!-- <b-form-input id="" type="text" v-model="one_at_time"  ></b-form-input> -->  </div>
                               </div>
                              <div class="row recurring">
                            <b-form-radio 
                                 v-model="selected" 
                                  
                                 name="some-radios" 
                                  class="col-sm-4"
                                 value="recurring">Recurring
                            </b-form-radio>
                          
                                 <div class="col-sm-3">
                                <select class="custom-select form-control" v-model="recurring_type"> 
                                    
                                    <option v-for="option in options"  v-bind:value="option.value">
                                        {{ option.text }}
                                      </option>
                                </select>
                            </div>
                            <div class="col-sm-1">At</div>
                              <div class="col-sm-4">
                                  <!-- <b-form-input id="recurring" type="text" v-model="recurring" placeholder="0" ></b-form-input> -->
                                  <b-form-timepicker v-model="recurring" locale="en"></b-form-timepicker>
                            </div>
                            </div>
                           <div class="row daily_every">
                             <b-form-radio 
                                 v-model="selected" 
                                 
                                 name="some-radios" 
                                  class="col-sm-3"
                                 value="daily_every">Daily Every
                            </b-form-radio>
                            <div class="col-sm-3">
                                <label>Hours</label>
                                 <b-form-input id="hour" v-model="hours" type="text" placeholder="0" ></b-form-input>
                            </div>
                            <div class="col-sm-3">
                                <label>Minutes</label>
                                 <b-form-input id="minutes" v-model="minutes" type="text" placeholder="0" ></b-form-input>
                            </div>
                             <div class="col-sm-3">
                                <label>Seconds</label>
                                 <b-form-input id="seconds" v-model="seconds" type="text" placeholder="0" ></b-form-input>
                            </div>
                            <div class="col-sm-4 offset-md-3 mt-3">
                                  <label>Start Time</label>
                                  <b-form-timepicker v-model="start_date_daily_every" locale="en"></b-form-timepicker>

                                  <!-- <b-form-input id="start_date_daily_every" v-model="start_date_daily_every" type="text"  ></b-form-input> --> 
                            </div>
                            <div class="col-sm-1"></div>
                            <div class="col-sm-4 mt-3">
                                  <label>End Time</label>
                               <!-- <b-form-input id="end_date_daily_every" v-model="end_date_daily_every" type="text"  ></b-form-input> -->
                               <b-form-timepicker v-model="end_date_daily_every" locale="en"></b-form-timepicker>
  
                                
                            </div>
                            </div><!-- end of row daily every -->
                          
                           
                            </b-form-group>

                            
                            
                             <b-form-group
                                label="URL  "
                                label-cols-sm="2"
                                label-align-sm="right"
                                
                            >
                               <b-form-input id="url" v-model="url" type="text" ></b-form-input>
                            </b-form-group>

                             <b-form-group
                                label="Username "
                                label-cols-sm="2"
                                label-align-sm="right"
                                
                            >
                               <b-form-input id="username" v-model="username" type="text" ></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label="Password"
                                label-cols-sm="2"
                                label-align-sm="right"
                                
                            >
                               <b-form-input id="password" v-model="password" type="password" ></b-form-input>
                            </b-form-group>

                            <b-form-group
                                label="Timeout (Sec)"
                                label-for="user-password"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input  id="timeout"v-model="timeout" type="text" ></b-form-input>
                            </b-form-group>
                             
                            

                             <b-form-group
                                label="API Key"
                                label-for="address"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                 <b-form-input id="api_key" v-model="api_key" type="text" ></b-form-input>
                            </b-form-group>

                            <b-form-group
                                label="Publish"
                                label-for="address"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                            <b-form-checkbox
                                id="checkbox-2"
                                
                               v-model="status"
                                
                                
                                false-value="no"
                                true-value="yes"
                                >
                              Save output to a file 
                            </b-form-checkbox>
                            </b-form-group>

                             <b-form-group
                                label="File"
                                label-for="address"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                 <b-form-input  type="text" v-model="file_name" ></b-form-input>
                            </b-form-group>

                           
                            
                            <b-button type="submit"  class="savebtn" variant="primary ml-3">Save</b-button>
                            <b-button type="reset"  class="savebtn" variant="primary ml-3">Cancel</b-button>
                             
                            <div class="clear"></div>
                            </div>
                        </b-card>
                   </div>
              </b-form>
           
       </div>
    </div>
</template>


<script>
  import axios from 'axios'
  export default {
    data() {
      return {
        username:'',
        password:'',
        event_name:'',
        start_date:'',
        end_date:'',
        selected:'',
        recurring_type:'',
        recurring:'',
        hours:'',
        minutes:'',
        seconds:'',
        start_date_daily_every:'',
        end_date_daily_every:'',
        timeout:'',
        api_key:'',
        one_at_time:'',
        group_name:'',
        url:"",
        status:'',
        file_name:'',
          options: [
              { text: 'Daily', value: 'Daily' },
              { text: 'Weekly', value: 'Weekly' },
              { text: 'Monthly', value: 'Monthly' },
              
            ],


        
      }
    },


    mounted() {
        this.editEvent();
    }
    ,
    methods:{
        async editEvent(){
          
           var id  =   localStorage.getItem('eventId');
                 axios.post('/api/edit-event',{id:id               
                    }).then((response) => {
                        if(response.data.record.status_code==200){
                            var data=response.data.record.message;
                            var durationdate=data.duration.split('&')

                               if(data.userid!=null){
                               this.username=data.userid.username;

                               this.password=data.userid.password;
                               }
                                this.event_name=data.event_name;
                                this.start_date=durationdate[0];
                                this.end_date=durationdate[1];
                                this.selected=data.frequency_type;
                                if(data.frequency_type==='one_at_time'){

                                    this.one_at_time=data.frequency;
                                }
                                else if(data.frequency_type==='recurring'){
                                    var recurring = data.frequency.split('&');

                                    console.log(recurring);
                                    this.recurring_type=recurring[0];
                                    this.recurring=recurring[1];

                                }else if(data.frequency_type==='daily_every'){

                                     var daily_every = data.frequency.split('&');

                                     this.hours=daily_every[0];
                                     this.minutes=daily_every[1];
                                     this.seconds=daily_every[2];
                                     this.start_date_daily_every=daily_every[3];
                                     this.end_date_daily_every=daily_every[4];


                                }

                               
                                this.timeout=data.timeout;
                                this.api_key=data.api_key;
                                this.group_name=data.group;
                                this.url=data.url;
                                this.file_name=data.file;


                        }else if(response.data.record.status_code==500){
                            this.$toast.success({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                            this.$toast.success({message:response.data.record.message})
                                localStorage.clear();
                            location.replace("/");
                        }
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });
        },
        async ResetEvent() {            
            location.replace("/dashboard");
        },    
       async UpdateEvent()
        {
            var frequency='';
            if(this.selected==='one_at_time'){
                frequency=this.one_at_time;
            }
            else if(this.selected==='recurring'){
                frequency=this.recurring_type+'&'+this.recurring;
            }
            else if(this.selected==='daily_every'){
                frequency=this.hours+'&'+this.minutes+'&'+this.seconds+'&'+this.start_date_daily_every+'&'+this.end_date_daily_every;
            }
           var  parameters = {
                username:this.username,
                password:this.password,
                event_name:this.event_name,
                frequency:frequency,
                frequency_type:this.selected,
                api_key:this.api_key,
                timeout:this.timeout,
                start_date:this.start_date,
                end_date:this.end_date,
                url:this.url,
                file_name:this.file_name,
                group:this.group_name,
                status:this.status,
                id:localStorage.getItem('eventId'),
                
            }
           //// console.log(parameters)
            await axios.post('/api/update-event',parameters
              ).then((response) => {
                    if(response.data.record.status_code==200){

                       
                         this.$toast.success({message:response.data.record.message})
                       location.replace("/dashboard");
                    }
                    else if(response.data.record.status_code==203)
                    {

                      
                            var  innerHTML= response.data.record.message
                            console.log(innerHTML);
                            for (var i = 0; i < innerHTML.length; i++) {
                                
                                 this.$toast.error({message:innerHTML[i]})
                                
                            }

                    }
                     else if(response.data.record.status_code==204)
                    {
                            this.$toast.error({message:response.data.record.message})
                                
                      
                    } else if(response.data.record.status_code==202)
                    {
                            this.$toast.error({message:response.data.record.message})
                                
                      
                    }
                    else if(response.data.record.status_code==403)
                    {

                         this.$toast.error({message:response.data.record.message})
                          localStorage.clear();
                            location.replace("/");
                      
                    }
                    ///console.log(response)
              },

              (error)=>{
                 console.log(error);
              }

              )
        }
    }
  }
</script>