<template>
    <div class="usermain">
       <div class="row">
                <b-form @submit.prevent="edit_user" id="form">
                   <div class="col-md-12">
                        
                         
                        <b-card bg-variant="light">
                            <h2>Edit  User </h2>
                            <div class="secbrder">
                            <b-form-group
                                label="User Name"
                                label-for="user-name"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-name" v-model="username" type="text" readonly></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label=" Full Name  "
                                label-cols-sm="2"
                                label-align-sm="right"
                               
                            >
                               <b-form-input id="full_name" type="text" v-model="fullName" required ></b-form-input>
                            </b-form-group>

                            <b-form-group
                                label="Company"
                                label-for="user-company"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-company" type="text" v-model="company" required></b-form-input>
                            </b-form-group>

                            <b-form-group
                                label="Email"
                                label-for="user-email"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-email" v-model="email" type="email" required></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label=" Alternate Email  "
                                label-cols-sm="2"
                                label-align-sm="right"
                              
                            >
                               <b-form-input id="alt_name_email" type="email"  v-model="alt_name_email"></b-form-input>
                            </b-form-group>
                             <b-form-group
                                label="Phone "
                                label-cols-sm="2"
                                label-align-sm="right"
                                
                            >
                               <b-form-input id="phone" type="number" v-model="phone" required></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label=" Cell Phone "
                                label-cols-sm="2"
                                label-align-sm="right"
                                
                            >
                               <b-form-input id="cell_phone" type="number" v-model="cell_phone" ></b-form-input>
                            </b-form-group>

                         
                             <b-form-group
                                label="Address"
                                label-for="address"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-textarea
                                      id="address"
                                      v-model="address"
                                      placeholder="Enter something..."
                                      rows="3"
                                      max-rows="6"
                                      
                                ></b-form-textarea>
                            </b-form-group>

                            <b-form-group
                                label="Security role"
                                label-for="security-role"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <select v-model="selected" class="form-control" required>
                                      <option v-for="option in options"  v-bind:value="option.value">
                                        {{ option.text }}
                                      </option>
                                </select>
                            </b-form-group>

                           
                            
                             <div class="row">
                                <div class="col-8"></div>
                                 <div class="col-2 ">
                                        <b-button type="button" @click="back()" class="savebtn" variant="primary">Cancel</b-button>
                                     
                                 </div>
                                 <div class="col-2">
                                        <b-button type="submit" class="savebtn" variant="primary">Save</b-button>
                                     
                                 </div>
                             </div>   
                            
                            <div class="clear"></div>
                            </div>
                        </b-card>
                   </div>
              </b-form>
           
       </div>
    </div>
</template>

<script>

import axios from 'axios'
export default({
   
    data () {
        return {
            username:'',
            email:'',
            company:'',
            address:'',
            phone:'',
            cell_phone:'',
            alt_name_email:'',
            fullName:'',
             selected: 'A',
            options: [
              { text: 'Guest', value: 'Guest' },
              { text: 'User', value: 'User' },
              { text: 'Company User', value: ' Company s User' },
              { text: 'Organization  User', value: ' Organization s User' }
            ],
           
        }
    }, 
    mounted () {
            this.showdetails()
    },
    methods:{
     showdetails() {
                var editid= localStorage.getItem('edituser',)
                 axios.post('/api/view-profile',{id:editid               
                    }).then((response) => {
                        if(response.data.record.status_code==200){
                            this.username=response.data.record.message.username;
                            this.fullName=response.data.record.message.fullName;
                            this.phone=response.data.record.message.phone;
                            this.cell_phone=response.data.record.message.cellPhone;
                            this.address=response.data.record.message.address;
                            this.company=response.data.record.message.company_name;
                            this.email=response.data.record.message.emailAddress;
                            this.alt_name_email=response.data.record.message.alternateEmailAddress;
                            this.selected=response.data.record.message.SecurityLevel;
                        }else if(response.data.record.status_code==500){
                            this.$toast.success({message:response.data.record.message})
                                
                        }
                        else if(response.data.record.status_code==403){
                            this.$toast.success({message:response.data.record.message})
                                localStorage.clear();
                            location.replace("/");
                        }
                        ///console.log(response);
                    },(error) => {
                        console.log(error);
                    });
             
        },
        async edit_user()
        {
           var  parameters = {
                username:this.username,
                email:this.email,
                security_Level:this.selected,
                company_name:this.company,
                billingaddressPart1:this.address,
                altemail:this.alt_name_email,
                phone:this.phone,
                cellphone:this.cell_phone,
                fullName:this.fullName,
                id:localStorage.getItem('edituser')
               

            }
           //// console.log(parameters)
            await axios.post('/api/edit-user',parameters
              ).then((response) => {
                    if(response.data.record.status_code==200){

                         this.$toast.success({message:response.data.record.message})
                       location.replace("/Userprofile");
                    }
                    else if(response.data.record.status_code==203)
                    {

                      
                       var  innerHTML= response.data.record.message
                           
                            for (var i = 0; i < innerHTML.length; i++) {
                                
                                 this.$toast.error({message:innerHTML[i]})
                                
                            }

                    }
                     else if(response.data.record.status_code==500)
                    {
                            this.$toast.error({message:response.data.record.message})
                                
                      
                    }
                    else if(response.data.record.status_code==202)
                    {
                            this.$toast.error({message:response.data.record.message})
                                
                      
                    }
                    else if(response.data.record.status_code==403)
                    {

                         this.$toast.error({message:response.data.record.message})
                          localStorage.clear();
                            location.replace("/");
                      
                    }
                    ///console.log(response)
              },

              (error)=>{
                 console.log(error);
              }

              )
        },
       async back(){
            location.replace("/Userprofile");
       }
    }
})
</script>