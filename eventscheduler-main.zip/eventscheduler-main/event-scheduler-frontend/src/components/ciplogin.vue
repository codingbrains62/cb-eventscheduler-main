<template>  <div class="login_form">
    <div class="innerwrp">
        <h1 class="heading">Login to Event Scheduler</h1>
        <div class="error"v-if="error" >{{ message }}</div>
        <b-form @submit.prevent="login">
        <b-form-group id="input-group-1" label-for="input-1"  >
            <b-form-input aria-describedby="text" :disabled="btndisable" id="input-1" v-model="email" type="text" placeholder="Username" autocomplete="off" ></b-form-input>
        </b-form-group>
        <b-form-group id="input-group-2" label-for="input-2">
            <b-form-input id="input-2"  v-model="password" type="password" placeholder="Password"  aria-describedby="password" :disabled="btndisable" autocomplete="off"></b-form-input>
        </b-form-group>
        <b-form-group id="input-group-4">
            <b-form-checkbox-group
            id="checkboxes-4"
            >
            <b-form-checkbox   v-model="toggle" true-value="yes" @change="remember_me" false-value="no" > Remember Me 
            </b-form-checkbox>
            </b-form-checkbox-group>
        </b-form-group>

        <b-button type="submit" class="loginbtn" variant="primary"    :disabled="btndisable">Sign In</b-button>
        </b-form>
        <a href="/forgotpassword" class="forgetbtn"  >Forgot password?</a>
    </div>
  </div>
</template>

<script>
///localStorage.setItem('error',this.error)
import axios from 'axios'

export default {

  name: "Login",

  data()
  {
    return {
      email: this.$cookies.get('usernamecookies')===null||undefined?'':this.$cookies.get('usernamecookies'),
      password: this.$cookies.get('passswordcookies')===null||undefined?'':this.$cookies.get('passswordcookies'),
      error:false,
      message:'',
      toggle : false,
      securityalert:localStorage.getItem('securityalert2'),
    }
  },
   computed: {
        btndisable: function() {
          if(this.securityalert > 2)
          {
             this.Security();
             this.error=true;
             this.message = "Your account is Disabled for next 12 Minutes ";
          }
            return this.securityalert > 2 ? true : false
        },
        
    } ,
    mounted() {
      this.checkcoookies();
    }
  ,
  methods:{
    async login()
    {
      //const apis = 'localhost:1337';
      axios.post('/api/login', {
        username: this.email,
        password: this.password
      })
      .then((response) => {
        //console.log(response);
        if(response.data.record.status_code== 202){
          this.securityalert++;
          localStorage.setItem('securityalert',this.securityalert)

           this.$toast.error({message:response.data.record.message});
             
          
        }
        else if(response.data.record.status_code==203)
        {
          this.securityalert++;
          localStorage.setItem('securityalert',this.securityalert)
           var  innerHTML= response.data.record.message
                           
                    for (var i = 0; i < innerHTML.length; i++) {
                        
                         this.$toast.error({message:innerHTML[i]})
                        
                    }

          // this.$toast.error({message:response.data.record.message[0]});
        }
        else if(response.data.record.status_code==500){
          this.$toast.error({ message:response.data.record.message })

        }
        else if(response.data.record.status_code== 200){
            this.$toast.success({message:response.data.record.message})
            localStorage.setItem('token',response.data.record.token);
            localStorage.setItem('username',response.data.record.data.username);
            localStorage.setItem('websitelinkid',response.data.record.data.WebsiteLinkID);
            localStorage.setItem('bookkeepingid',response.data.record.data.bookkeepingId);
            localStorage.setItem('fullname', response.data.record.data.fullName);
            localStorage.setItem('userid', response.data.record.data.id);
            localStorage.setItem('emailAddress', response.data.record.data.emailAddress);
            localStorage.setItem('phone', response.data.record.data.phone);
            localStorage.setItem('securityalert',0);
            location.replace("/dashboard");
        }
      }, (error) => {
        console.log(error);
      });
      //console.warn(this.email, this.password)
    },
   async Security() {
    //const apis = 'localhost:1337';
      axios.post('/api/security', {
        username: this.email,
        password: this.password
      })
      .then((response) => {
      }, (error) => {
        console.log(error);
      });

     setTimeout(function () { this.securityalertstorage() }.bind(this), (12*60000))
    },
    async securityalertstorage() {

      localStorage.setItem('securityalert',0);
      this.error=false;
      this.message='';
      window.location.reload()
    },
      remember_me: function () {
        console.log(this.toggle)
        
       if(this.toggle=='true')
       {
             this.$cookies.set('usernamecookies',this.email, "7D") ;
              this.$cookies.set('passswordcookies',this.password, "7D");

        
       }
       else 
       {
           this.$cookies.remove("usernamecookies");
           this.$cookies.remove("passswordcookies");
           ///this.$cookies.keys().forEach(cookie => this.$cookies.remove(cookie))
          
       }
          // this.$cookies.remove('passswordcookies');
    },
    checkcoookies: function()
    {
      console.log(this.toggle)
      if(this.$cookies.get('usernamecookies') && this.$cookies.get('passswordcookies')){
        this.toggle=true;

      }
      else{

        this.toggle=false;
      }
     

    }
  }
}


</script>
