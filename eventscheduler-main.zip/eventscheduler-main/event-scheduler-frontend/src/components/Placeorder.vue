<template>
  <div class="container-fluid">
    <div class="row place_order">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h2>PLACE AN ORDER</h2>
            <p>
              Please review your information and let us know what you wish to
              order. If you have any questions, contact CLAS at (800) 952-5696
              or<br />
              <a href="#" class="email_link"> connect@clasinfo.com.</a>
            </p>
            <p>
              <span class="requires_field">*</span> Indicates required field
            </p>
          </div>
        </div>
      </div>
    </div>
    <b-form @submit.prevent="orderplace">
      <div class="row order_form_row">
        <div class="container">
          <div class="row">
            <h4 class="content_heading">REQUESTOR INFORMATION (REQUIRED)</h4>
            <div class="col-md-6">

              <b-form-group :class="{ 'form-group--error': $v.name.$error }">
                 <label>First Name <span class="requires_field">*</span></label>
                <b-form-input
                  id=""
                  type="text"
                  class="form__input"
                  placeholder="Enter First Name"
                  v-model.trim="$v.name.$model"
                ></b-form-input>
              </b-form-group>
              
              <div class="error1"  v-if="!$v.name.required">Please enter first name</div>
              <div class="error1" v-if="!$v.name.alpha">Accept only alphabet characters.</div>
              
            </div>
            <div class="col-md-6">
              <b-form-group :class="{ 'form-group--error': $v.lastname.$error }">
                
                  <label>Last Name <span class="requires_field">*</span></label>
                <b-form-input
                  id=""
                  type="text"
                   class="form__input"
                  placeholder="Enter Last Name"
                  v-model.trim="$v.lastname.$model"
                ></b-form-input>
              </b-form-group>
              <div class="error1" v-if="!$v.lastname.required">Please enter last name </div>
              <div class="error1" v-if="!$v.lastname.alpha">Accepts only alphabet characters.</div>
              
            </div>
            <div class="col-md-12">
              <b-form-group :class="{ 'form-group--error': $v.company_name.$error }">
                <label>Company Name <span class="requires_field">*</span></label>
                <b-form-input
                  id=""
                  type="text"
                   class="form__input"
                  placeholder="Enter Company Name"
                  v-model.trim="$v.company_name.$model"
                ></b-form-input>
              </b-form-group>
               <div class="error1" v-if="!$v.company_name.required">Please enter company name</div>
               <div class="error1" v-if="!$v.company_name.alpha">Accepts only alphabet characters.</div>
              
            </div>
            <div class="col-md-6">
              <b-form-group :class="{ 'form-group--error': $v.email.$error }">
                <label>Email Address <span class="requires_field">*</span></label>
                <b-form-input
                  id=""
                  type ="text"
                  class ="form__input"
                  placeholder ="Enter Email Address"
                  v-model.trim ="$v.email.$model"
                ></b-form-input>
              </b-form-group>
              <div class="error1" v-if="!$v.email.required">Please enter email address</div>
              <div class="error1" v-if="!$v.email.email">Please enter valid email Address</div>
            </div>
            <div class="col-md-6">
              <b-form-group :class="{ 'form-group--error': $v.mobile.$error }">
                <label>Phone Number <span class="requires_field">*</span></label>
                <b-form-input
                  id=""
                  type="number"
                  class="form__input"
                  placeholder="Enter Phone Number"
                  v-model.trim="$v.mobile.$model"
                ></b-form-input>
              </b-form-group >
              <div   class="error1" v-if="!$v.mobile.required">Please enter phone number</div>
              <div class="error1" v-if="!$v.mobile.minLength">Phone number must have at least {{$v.mobile.$params.minLength.min}} digitas. </div>
              <div class="error1" v-if="!$v.mobile.maxLength">Phone number must have at least {{$v.mobile.$params.maxLength.max}} digitas. </div>
              <div class="error1" v-if="!$v.mobile.numeric">Please enter numeric number </div>

            </div>
            <div class="col-md-12">
              <b-form-group :class="{ 'form-group--error': $v.address.$error }">
                <label>Street Address <span class="requires_field">*</span></label>
                <b-form-input
                  id=""
                  type="text"
                  class="form__input"
                  placeholder="Enter Street Address"
                  v-model.trim="$v.address.$model"
                ></b-form-input>
              </b-form-group>
              <div class="error1" v-if="!$v.address.required">Please enter street address</div>
            </div>
            <div class="col-md-6">
              <b-form-group :class="{ 'form-group--error': $v.city.$error }">
                <label>City <span class="requires_field">*</span></label>
                <b-form-input
                  id =""
                  type="text"
                  class="form__input"
                  placeholder="Enter City"
                  v-model.trim="$v.city.$model"
                ></b-form-input>
              </b-form-group>
              <div class="error1" v-if="!$v.city.required">Please enter city name</div>
               <div class="error1" v-if="!$v.city.alpha">Accepts only alphabet characters.</div>
            </div>
            <div class="col-md-6">
              <b-form-group :class="{ 'form-group--error': $v.state.$error }">
                 <label>State <span class="requires_field">*</span></label>
                <b-form-select class="form-control form__input" v-model.trim="$v.state.$model">
                  <b-form-select-option value="null"
                    >State</b-form-select-option
                  >
                   <b-form-select-option value="AL">Alabama</b-form-select-option>
                    <b-form-select-option value="AK">Alaska</b-form-select-option>
                    <b-form-select-option value="AZ">Arizona</b-form-select-option>
                    <b-form-select-option value="AR">Arkansas</b-form-select-option>
                    <b-form-select-option value="CA">California</b-form-select-option>
                    <b-form-select-option value="CO">Colorado</b-form-select-option>
                    <b-form-select-option value="CT">Connecticut</b-form-select-option>
                    <b-form-select-option value="DE">Delaware</b-form-select-option>
                    <b-form-select-option value="DC">District Of Columbia</b-form-select-option>
                    <b-form-select-option value="FL">Florida</b-form-select-option>
                    <b-form-select-option value="GA">Georgia</b-form-select-option>
                    <b-form-select-option value="HI">Hawaii</b-form-select-option>
                    <b-form-select-option value="ID">Idaho</b-form-select-option>
                    <b-form-select-option value="IL">Illinois</b-form-select-option>
                    <b-form-select-option value="IN">Indiana</b-form-select-option>
                    <b-form-select-option value="IA">Iowa</b-form-select-option>
                    <b-form-select-option value="KS">Kansas</b-form-select-option>
                    <b-form-select-option value="KY">Kentucky</b-form-select-option>
                    <b-form-select-option value="LA">Louisiana</b-form-select-option>
                    <b-form-select-option value="ME">Maine</b-form-select-option>
                    <b-form-select-option value="MD">Maryland</b-form-select-option>
                    <b-form-select-option value="MA">Massachusetts</b-form-select-option>
                    <b-form-select-option value="MI">Michigan</b-form-select-option>
                    <b-form-select-option value="MN">Minnesota</b-form-select-option>
                    <b-form-select-option value="MS">Mississippi</b-form-select-option>
                    <b-form-select-option value="MO">Missouri</b-form-select-option>
                    <b-form-select-option value="MT">Montana</b-form-select-option>
                    <b-form-select-option value="NE">Nebraska</b-form-select-option>
                    <b-form-select-option value="NV">Nevada</b-form-select-option>
                    <b-form-select-option value="NH">New Hampshire</b-form-select-option>
                    <b-form-select-option value="NJ">New Jersey</b-form-select-option>
                    <b-form-select-option value="NM">New Mexico</b-form-select-option>
                    <b-form-select-option value="NY">New York</b-form-select-option>
                    <b-form-select-option value="NC">North Carolina</b-form-select-option>
                    <b-form-select-option value="ND">North Dakota</b-form-select-option>
                    <b-form-select-option value="OH">Ohio</b-form-select-option>
                    <b-form-select-option value="OK">Oklahoma</b-form-select-option>
                    <b-form-select-option value="OR">Oregon</b-form-select-option>
                    <b-form-select-option value="PA">Pennsylvania</b-form-select-option>
                    <b-form-select-option value="RI">Rhode Island</b-form-select-option>
                    <b-form-select-option value="SC">South Carolina</b-form-select-option>
                    <b-form-select-option value="SD">South Dakota</b-form-select-option>
                    <b-form-select-option value="TN">Tennessee</b-form-select-option>
                    <b-form-select-option value="TX">Texas</b-form-select-option>
                    <b-form-select-option value="UT">Utah</b-form-select-option>
                    <b-form-select-option value="VT">Vermont</b-form-select-option>
                    <b-form-select-option value="VA">Virginia</b-form-select-option>
                    <b-form-select-option value="WA">Washington</b-form-select-option>
                    <b-form-select-option value="WV">West Virginia</b-form-select-option>
                    <b-form-select-option value="WI">Wisconsin</b-form-select-option>
                    <b-form-select-option value="WY">Wyoming</b-form-select-option>
                </b-form-select>
              </b-form-group>
              <div class="error1" v-if="!$v.state.required">Please enter state name</div>
            </div>
            <div class="col-md-6">
              <b-form-group :class="{ 'form-group--error': $v.postal_code.$error }">
                 <label>Postal Code <span class="requires_field">*</span></label>
                <b-form-input
                  id =""
                  type="text"
                  class="form__input"
                  placeholder ="Enter Postal Code"
                  v-model.trim ="$v.postal_code.$model"
                ></b-form-input>
              </b-form-group>
                <div class="error1" v-if="!$v.postal_code.required">Please enter Postal code</div>
               <div class="error1" v-if="!$v.postal_code.numeric">Accepts only numerics </div>
              <!--  <div class="error1" v-if="!$v.postal_code.maxLength">Postal  number must have at least {{$v.postal_code.$params.maxLength.max}} digitas. </div> -->
              
            </div>
            <div class="col-md-6">
              <b-form-group :class="{ 'form-group--error': $v.country.$error }">
                <label>Country <span class="requires_field">*</span></label>
                <b-form-input
                  id=""
                  type="text"
                  class="form__input"
                  placeholder="Enter Country"
                  v-model.trim="$v.country.$model"
                ></b-form-input>
              </b-form-group>
              <div class="error1" v-if="!$v.country.required">Please enter country name</div>
               
            </div>
            <div class="col-md-12">
              <label>Are you an existing CLAS client?</label>
              <b-form-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="me">Yes</b-form-checkbox>
                  <b-form-checkbox value="that">No</b-form-checkbox>
                </b-form-checkbox-group>
              </b-form-group>
            </div>
            <div class="col-md-6">
              <b-form-group
               
              >
              <label>If yes, please provide your CLAS account number, if known<span class="requires_field">*</span></label>
                <b-form-input
                  id=""
                  type="text"
                  v-model="clas_acount_number"
                  placeholder="Enter CLAS Account Number"
                ></b-form-input>
              </b-form-group>
            </div>
          </div>
        </div>
      </div>
      <!-- end of row order_form_row -->
      <div class="row billing_information">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <h4 class="content_heading">
                BILLING INFORMATION (IF DIFFERENT FROM REQUESTOR; NOT NEEDED FOR
                RETURN USERS)
              </h4>
              <b-form-group>
                <b-form-checkbox-group>
                  <b-form-checkbox @change="check($event)"   v-model="checked"
                    >Same Information as Requestor</b-form-checkbox
                  >
                </b-form-checkbox-group>
              </b-form-group>
            </div>
            <div class="row" v-show="isShowing"> 
            <div class="col-md-6">
              <b-form-group label="First Name" :class="{ 'form-group--error': $v.billing_information_first_name.$error }">
                <b-form-input
                  id=""
                  type="text"
                  v-model.trim="$v.billing_information_first_name.$model"
                  placeholder="Enter First Name"
                ></b-form-input>
              </b-form-group>
              <div class="error1"  v-if="!$v.billing_information_first_name.required">Please enter first name</div>
              <!-- <div class="error1" v-if="!$v.billing_information_first_name.alpha">Accept only alphabet characters.</div> -->
            </div>
            <div class="col-md-6">
              <b-form-group label="Last Name" :class="{ 'form-group--error': $v.billing_information_last_name.$error }">
                <b-form-input
                  id=""
                  type="text"
                  v-model.trim="$v.billing_information_last_name.$model"
                  placeholder="Enter Last Name"
                ></b-form-input>

              </b-form-group>
               <div class="error1" v-if="!$v.billing_information_last_name.required">Please enter last name </div>
          
            </div>
            <div class="col-md-6">
              <b-form-group label="Email Address" :class="{ 'form-group--error': $v.billing_information_email.$error }">
                <b-form-input
                  id=""
                  type="text"
                 v-model.trim="$v.billing_information_email.$model"
                  placeholder="Enter Email Address"
                ></b-form-input>
              </b-form-group>
                  <div class="error1" v-if="!$v.billing_information_email.required">Please enter email address</div>
              <div class="error1" v-if="!$v.billing_information_email.email">Please enter valid email Address</div>
            </div>
            <div class="col-md-6">
              <b-form-group label="Phone Number" :class="{ 'form-group--error': $v.billing_information_mobile.$error }">
                <b-form-input
                  id=""
                  type="number"
                 v-model.trim="$v.billing_information_mobile.$model"
                  placeholder="Enter Phone Number"
                ></b-form-input>
              </b-form-group>
               <div   class="error1" v-if="!$v.billing_information_mobile.required">Please enter phone number</div>
              <div class="error1" v-if="!$v.billing_information_mobile.minLength">Phone number must have at least {{$v.billing_information_mobile.$params.minLength.min}} digitas. </div>
              <div class="error1" v-if="!$v.billing_information_mobile.maxLength">Phone number must have at least {{$v.billing_information_mobile.$params.maxLength.max}} digitas. </div>
              <div class="error1" v-if="!$v.billing_information_mobile.numeric">Please enter numeric number </div>
            </div>
            <div class="col-md-12">
              <b-form-group label="Street Address" :class="{ 'form-group--error': $v.billing_information_address.$error }">
                <b-form-input
                  id=""
                  type="text"
                  v-model.trim="$v.billing_information_address.$model"
                  placeholder="Enter Street Address"
                ></b-form-input>
              </b-form-group>
               <div   class="error1" v-if="!$v.billing_information_address.required">Please enter address</div>
            </div>
            <div class="col-md-6">
              <b-form-group label="City" :class="{ 'form-group--error': $v.billing_information_city.$error }">
                <b-form-input
                  id=""
                  type="text"
                  v-model.trim="$v.billing_information_city.$model"
                  placeholder="Enter City"
                ></b-form-input>
              </b-form-group>
              <div class="error1" v-if="!$v.billing_information_city.required">Please enter city name</div>

            </div>
            <div class="col-md-6">
              <b-form-group label="State"  :class="{ 'form-group--error': $v.billing_information_state.$error }">
                <b-form-select class="form-control" v-model.trim="$v.billing_information_state.$model">
                  <b-form-select-option value="null"
                    >State</b-form-select-option
                  >
                    <b-form-select-option value="AL">Alabama</b-form-select-option>
                    <b-form-select-option value="AK">Alaska</b-form-select-option>
                    <b-form-select-option value="AZ">Arizona</b-form-select-option>
                    <b-form-select-option value="AR">Arkansas</b-form-select-option>
                    <b-form-select-option value="CA">California</b-form-select-option>
                    <b-form-select-option value="CO">Colorado</b-form-select-option>
                    <b-form-select-option value="CT">Connecticut</b-form-select-option>
                    <b-form-select-option value="DE">Delaware</b-form-select-option>
                    <b-form-select-option value="DC">District Of Columbia</b-form-select-option>
                    <b-form-select-option value="FL">Florida</b-form-select-option>
                    <b-form-select-option value="GA">Georgia</b-form-select-option>
                    <b-form-select-option value="HI">Hawaii</b-form-select-option>
                    <b-form-select-option value="ID">Idaho</b-form-select-option>
                    <b-form-select-option value="IL">Illinois</b-form-select-option>
                    <b-form-select-option value="IN">Indiana</b-form-select-option>
                    <b-form-select-option value="IA">Iowa</b-form-select-option>
                    <b-form-select-option value="KS">Kansas</b-form-select-option>
                    <b-form-select-option value="KY">Kentucky</b-form-select-option>
                    <b-form-select-option value="LA">Louisiana</b-form-select-option>
                    <b-form-select-option value="ME">Maine</b-form-select-option>
                    <b-form-select-option value="MD">Maryland</b-form-select-option>
                    <b-form-select-option value="MA">Massachusetts</b-form-select-option>
                    <b-form-select-option value="MI">Michigan</b-form-select-option>
                    <b-form-select-option value="MN">Minnesota</b-form-select-option>
                    <b-form-select-option value="MS">Mississippi</b-form-select-option>
                    <b-form-select-option value="MO">Missouri</b-form-select-option>
                    <b-form-select-option value="MT">Montana</b-form-select-option>
                    <b-form-select-option value="NE">Nebraska</b-form-select-option>
                    <b-form-select-option value="NV">Nevada</b-form-select-option>
                    <b-form-select-option value="NH">New Hampshire</b-form-select-option>
                    <b-form-select-option value="NJ">New Jersey</b-form-select-option>
                    <b-form-select-option value="NM">New Mexico</b-form-select-option>
                    <b-form-select-option value="NY">New York</b-form-select-option>
                    <b-form-select-option value="NC">North Carolina</b-form-select-option>
                    <b-form-select-option value="ND">North Dakota</b-form-select-option>
                    <b-form-select-option value="OH">Ohio</b-form-select-option>
                    <b-form-select-option value="OK">Oklahoma</b-form-select-option>
                    <b-form-select-option value="OR">Oregon</b-form-select-option>
                    <b-form-select-option value="PA">Pennsylvania</b-form-select-option>
                    <b-form-select-option value="RI">Rhode Island</b-form-select-option>
                    <b-form-select-option value="SC">South Carolina</b-form-select-option>
                    <b-form-select-option value="SD">South Dakota</b-form-select-option>
                    <b-form-select-option value="TN">Tennessee</b-form-select-option>
                    <b-form-select-option value="TX">Texas</b-form-select-option>
                    <b-form-select-option value="UT">Utah</b-form-select-option>
                    <b-form-select-option value="VT">Vermont</b-form-select-option>
                    <b-form-select-option value="VA">Virginia</b-form-select-option>
                    <b-form-select-option value="WA">Washington</b-form-select-option>
                    <b-form-select-option value="WV">West Virginia</b-form-select-option>
                    <b-form-select-option value="WI">Wisconsin</b-form-select-option>
                    <b-form-select-option value="WY">Wyoming</b-form-select-option>
                </b-form-select>
              </b-form-group>
              <div class="error1" v-if="!$v.billing_information_state.required">Please select state name</div>

            </div>
            <div class="col-md-6">
              <b-form-group label="Postal Code":class="{ 'form-group--error': $v.billing_information_postal_code.$error }">
                <b-form-input
                  id=""
                  type="text"
                  v-model.trim="$v.billing_information_postal_code.$model"
                  placeholder="Enter Postal Code"
                ></b-form-input>
              </b-form-group>
              <div class="error1" v-if="!$v.billing_information_postal_code.required">Please enter Postal code</div>
               <div class="error1" v-if="!$v.billing_information_postal_code.numeric">Accepts only numerics </div>
              <!--  <div class="error1" v-if="!$v.billing_information_postal_code.maxLength">Postal  number  {{$v.billing_information_postal_code.$params.maxLength.max}} digitas. </div> -->
              
            </div>
            <div class="col-md-6">
              <b-form-group label="Country":class="{ 'form-group--error': $v.billing_information_country.$error }">
                <b-form-input
                  id=""
                  type="text"
                  
                  v-model.trim="$v.billing_information_country.$model"
                  placeholder="Enter Country"
                ></b-form-input>

              </b-form-group>
              <div class="error1" v-if="!$v.billing_information_country.required">Please enter country name</div>
              
            </div>
           </div>
          </div>
        </div>
      </div>
      <!-- end of billing_information -->
      <div class="row order_information">
        <div class="container">
          <div class="row">
            <h4 class="content_heading">
              ORDER INFORMATION (IF DIFFERENT FROM REQUESTOR; NOT NEEDED FOR
              RETURN USERS)
            </h4>
            <div class="col-md-6">
              <b-form-group label="Reference Name/Number">
                <b-form-input
                  id=""
                  type="text"
                  v-model="refernce_number"
                  placeholder="Reference Name/Number"
                ></b-form-input>
              </b-form-group>
            </div>
            <div class="col-md-12 add_remove">
              <div v-for="(item, index) in $v.inputs.$each.$iter" :key="index"  >
                <b-form-group :class="{ 'form-group--error': item.service_name.$error }"  label="Target Name(s) for Services *">
                  <b-form-input
                    id=""
                    type="text"
                    placeholder="Location where services are to be performed "
                    v-model.trim="item.service_name.$model"
                  ></b-form-input>
                </b-form-group>
                  <div class="error1" style="text-align: left;" v-if="!item.service_name.required">Please enter location </div>
                  <div class="error1" style="text-align: left;" v-if="!item.service_name.minLength">Location Name must have at least {{ item.service_name.$params.minLength.min }} letters.</div>
            </div>
              <b-button type="button" class="btn_addmore" variant="primary" v-on:click="addInput()"
                >Add More </b-button
              >
              <b-button v-if="inputs.length > 1" type="button" class="btn_removelast" variant="primary" v-on:click="removeInput()"
                >Remove Last</b-button
              >
            </div>
            <div class="col-md-12 add_remove">
              <div  v-for="(item, index) in $v.inputs1.$each.$iter" :key="index">
                <b-form-group :class="{ 'form-group--error': item.service_name1.$error }"
                  label="Location(s) where services are to be performed *"
                >
                  <b-form-input
                    id=""
                    type="text"
                    class="form__input"
                    placeholder="Location(s) where services are to be performed"
                    v-model.trim="item.service_name1.$model"
                  ></b-form-input>
                </b-form-group>
                <div class="error1" style="text-align: left;" v-if="!item.service_name1.required">
                    Please enter location .</div>
                  <div class="error1" style="text-align: left;" v-if="!item.service_name1.minLength">Location   must have at least {{ item.service_name1.$params.minLength.min }} letters.</div>
              </div>
              <b-button type="button" class="btn_addmore" variant="primary" v-on:click="addInput1()"
                >Add More</b-button
              >
              <b-button type="button" v-if="inputs1.length > 1" class="btn_removelast" variant="primary" v-on:click="removeInput1()"
                >Remove Last</b-button
              >
            </div>
          </div>
        </div>
      </div>
      <!-- end of row order_information -->
      <div class="row service_requested">
        <div class="container">
          <div class="row">
            <h4 class="content_heading">SERVICES REQUESTED</h4>
            <p>
              Services requested below will be performed for each Target Name in
              each of the Locations(s) entered.
            </p>
            <h5 class="corporate_service_heading">Corporate Services</h5>
            <div class="col-md-12">
              <b-form-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="" id="Certificate"
                    >Good Standing/Status Certificate</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="" id="CorpCheck"
                    >CLAS CorpCheck™ (Abstract of Corporate Data from State
                    Records)</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="" id="state_report"
                    >Status Report (Report of current entity
                    staus)</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="" id="Incorporation"
                    >Articles of Incorporation/Qualification (Originating
                    documents)</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group class="sub_checkbox">
                  <b-form-checkbox value="Certified_Copies" id="Certified_Copies">Certified Copies</b-form-checkbox>
                  <b-form-checkbox value="plain_copies" id="plain_copies">Plain Copies</b-form-checkbox>
                  <b-form-checkbox value="subsequent" id="subsequent"
                    >Include subsequent filings (Amendments, Mergers,
                    Dissolutions, etc.)</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="" id="annual-report"
                    >Annual Report (aka Statement of Information, Annual List,
                    etc.)</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group class="sub_checkbox">
                  <b-form-checkbox value="Certified-Copies" id="Certified-Copies">Certified Copies</b-form-checkbox>
                  <b-form-checkbox value="plain_copie" id="plain_copie">Plain Copies</b-form-checkbox>
                  <b-form-checkbox value="most_recent" id="most_recent"
                    >Most Recent
                    <span class="underline">OR</span></b-form-checkbox
                  >
                  <b-form-checkbox value="Most_Recent_Complete" id="underline"
                    >Most_Recent_Complete<span class="underline"
                      >OR</span
                    ></b-form-checkbox
                  >
                  <b-form-checkbox value="all-on-file" id="all-on-file">All On File</b-form-checkbox>
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="Tax Status Letter/Certificate" id="tax-status"
                    >Tax Status Letter/Certificate</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="assumed-fictition" id="assumed-fictition"
                    >Assumed/Fictitious Business Name Search</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="name-availability" id="name-availability"
                    >Name Availability Check</b-form-checkbox
                  >
                  <b-form-checkbox value="name-reservation" id="name-reservation">Name Reservation</b-form-checkbox>
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="corporate-or" id="corporate-or"
                    >Corporate or LLC Kit/Minute Book</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="Registered Agent Representation" id="Registered"
                    >Registered Agent Representation</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="Annual Report Management Service" id="annual-report-management"
                    >Annual Report Management Service</b-form-checkbox
                  >
                </b-form-checkbox-group>
              </b-form-group>
            </div>
          </div>
        </div>
      </div>
      <!-- end of service_requested -->
      <div class="row litigation_service">
        <div class="container">
          <div class="row">
            <h5 class="litigation_service_heading">
              UCC, Lien and Litigation Services
            </h5>
            <div class="col-md-12">
              <b-form-checkbox-group>
                <b-form-checkbox value="State UCC and Lien Search"
                  >State UCC and Lien Search</b-form-checkbox
                >
              </b-form-checkbox-group>
              <b-form-checkbox-group class="sub_checkbox">
                <b-form-checkbox value="Preliminary/Plain Search"
                  >Preliminary/Plain Search</b-form-checkbox
                >
                <b-form-checkbox value="Certified/Official Search"
                  >Certified/Official Search</b-form-checkbox
                >
              </b-form-checkbox-group>
              <b-form-checkbox-group class="sub_checkbox">
                <p class="indicate_copy">
                  Please indicate your copy preferences below:
                </p>
                <b-form-checkbox value="With Full Copies">With Full Copies</b-form-checkbox>
                <b-form-checkbox value="Copies Updated From">Copies Updated From </b-form-checkbox>

                <b-form-input
                  id=""
                  type="text"
                  placeholder=""
                  class="indicate_form"
                ></b-form-input>

                <b-form-checkbox value="Include copies for lapsed/terminated filings"
                  >Include copies for lapsed/terminated filings</b-form-checkbox
                >
                <b-form-checkbox value="Listing Only (no copies)"
                  >Listing Only (no copies)
                </b-form-checkbox>
              </b-form-checkbox-group>
              <b-form-checkbox-group>
                <b-form-checkbox value="County Fixture Filing Search"
                  >County Fixture Filing Search</b-form-checkbox
                >
              </b-form-checkbox-group>
              <b-form-checkbox-group>
                <b-form-checkbox value="Federal Tax Liens">Federal Tax Liens</b-form-checkbox>
                <b-form-checkbox value="State Tax Liens">State Tax Liens</b-form-checkbox>
                <b-form-checkbox value="Judgment Liens (Abstracts of Judgment)"
                  >Judgment Liens (Abstracts of Judgment)</b-form-checkbox
                >
              </b-form-checkbox-group>
              <b-form-checkbox-group class="sub_checkbox">
                <p class="indicate_copy">
                  Please indicate your copy preferences below:
                </p>
                <b-form-checkbox value="With Full Copies">With Full Copies</b-form-checkbox>
                <b-form-checkbox value="Copies Updated From">Copies Updated From </b-form-checkbox>

                <b-form-input
                  id=""
                  type="text"
                  placeholder=""
                  class="indicate_form"
                ></b-form-input>
                <b-form-checkbox value="Include copies for lapsed/terminated filings"
                  >Include copies for lapsed/terminated filings</b-form-checkbox
                >
                <b-form-checkbox value="Listing Only (no copies)"
                  >Listing Only (no copies)
                </b-form-checkbox>
              </b-form-checkbox-group>
              <b-form-checkbox-group>
                <b-form-checkbox value="State Court Search - Civil Suits (Superior Court, District
                  Court, etc.)"
                  >State Court Search - Civil Suits (Superior Court, District
                  Court, etc.)</b-form-checkbox
                >
              </b-form-checkbox-group>
              <b-form-checkbox-group>
                <b-form-checkbox value="U.S. District Court Search - Civil Suits"
                  >U.S. District Court Search - Civil Suits</b-form-checkbox
                >
              </b-form-checkbox-group>
              <b-form-checkbox-group>
                <b-form-checkbox value="Bankruptcy Search">Bankruptcy Search</b-form-checkbox>
              </b-form-checkbox-group>
              <b-form-checkbox-group>
                <b-form-checkbox value="CLAS EXCLUSIVE Lien and Litigation Search"
                  >CLAS EXCLUSIVE Lien and Litigation Search
                  Package™</b-form-checkbox
                >
              </b-form-checkbox-group>
              <p class="service_con">
                Includes State and County UCCs, Fixture Filings, Federal and
                State Tax Liens and Judgment Liens, State and Federal Litigation
                and Bankruptcy Searches - combined for one low rate!
              </p>
            </div>
          </div>
        </div>
      </div>
      <!-- end of litigation_service row -->
      <div class="row real_property_service">
        <div class="container">
          <div class="row">
            <h5 class="real_property_service_heading">
              Real Property Services
            </h5>
            <p>Property Address for Services</p>
            <div class="col-md-12">
              <b-form-group label="Street Address ">
                <b-form-input
                  id=""
                  type="text"
                  placeholder="Enter Street Address"
                ></b-form-input>
              </b-form-group>
            </div>
            <div class="col-md-6">
              <b-form-group label="City">
                <b-form-input
                  id=""
                  type="text"
                  placeholder="Enter City"
                ></b-form-input>
              </b-form-group>
            </div>
            <div class="col-md-6">
              <b-form-group label="State">
                <b-form-select class="form-control">
                  <b-form-select-option value="null"
                    >State</b-form-select-option
                  >
                    <b-form-select-option value="AL">Alabama</b-form-select-option>
                    <b-form-select-option value="AK">Alaska</b-form-select-option>
                    <b-form-select-option value="AZ">Arizona</b-form-select-option>
                    <b-form-select-option value="AR">Arkansas</b-form-select-option>
                    <b-form-select-option value="CA">California</b-form-select-option>
                    <b-form-select-option value="CO">Colorado</b-form-select-option>
                    <b-form-select-option value="CT">Connecticut</b-form-select-option>
                    <b-form-select-option value="DE">Delaware</b-form-select-option>
                    <b-form-select-option value="DC">District Of Columbia</b-form-select-option>
                    <b-form-select-option value="FL">Florida</b-form-select-option>
                    <b-form-select-option value="GA">Georgia</b-form-select-option>
                    <b-form-select-option value="HI">Hawaii</b-form-select-option>
                    <b-form-select-option value="ID">Idaho</b-form-select-option>
                    <b-form-select-option value="IL">Illinois</b-form-select-option>
                    <b-form-select-option value="IN">Indiana</b-form-select-option>
                    <b-form-select-option value="IA">Iowa</b-form-select-option>
                    <b-form-select-option value="KS">Kansas</b-form-select-option>
                    <b-form-select-option value="KY">Kentucky</b-form-select-option>
                    <b-form-select-option value="LA">Louisiana</b-form-select-option>
                    <b-form-select-option value="ME">Maine</b-form-select-option>
                    <b-form-select-option value="MD">Maryland</b-form-select-option>
                    <b-form-select-option value="MA">Massachusetts</b-form-select-option>
                    <b-form-select-option value="MI">Michigan</b-form-select-option>
                    <b-form-select-option value="MN">Minnesota</b-form-select-option>
                    <b-form-select-option value="MS">Mississippi</b-form-select-option>
                    <b-form-select-option value="MO">Missouri</b-form-select-option>
                    <b-form-select-option value="MT">Montana</b-form-select-option>
                    <b-form-select-option value="NE">Nebraska</b-form-select-option>
                    <b-form-select-option value="NV">Nevada</b-form-select-option>
                    <b-form-select-option value="NH">New Hampshire</b-form-select-option>
                    <b-form-select-option value="NJ">New Jersey</b-form-select-option>
                    <b-form-select-option value="NM">New Mexico</b-form-select-option>
                    <b-form-select-option value="NY">New York</b-form-select-option>
                    <b-form-select-option value="NC">North Carolina</b-form-select-option>
                    <b-form-select-option value="ND">North Dakota</b-form-select-option>
                    <b-form-select-option value="OH">Ohio</b-form-select-option>
                    <b-form-select-option value="OK">Oklahoma</b-form-select-option>
                    <b-form-select-option value="OR">Oregon</b-form-select-option>
                    <b-form-select-option value="PA">Pennsylvania</b-form-select-option>
                    <b-form-select-option value="RI">Rhode Island</b-form-select-option>
                    <b-form-select-option value="SC">South Carolina</b-form-select-option>
                    <b-form-select-option value="SD">South Dakota</b-form-select-option>
                    <b-form-select-option value="TN">Tennessee</b-form-select-option>
                    <b-form-select-option value="TX">Texas</b-form-select-option>
                    <b-form-select-option value="UT">Utah</b-form-select-option>
                    <b-form-select-option value="VT">Vermont</b-form-select-option>
                    <b-form-select-option value="VA">Virginia</b-form-select-option>
                    <b-form-select-option value="WA">Washington</b-form-select-option>
                    <b-form-select-option value="WV">West Virginia</b-form-select-option>
                    <b-form-select-option value="WI">Wisconsin</b-form-select-option>
                    <b-form-select-option value="WY">Wyoming</b-form-select-option>
                </b-form-select>
              </b-form-group>
            </div>
            <div class="col-md-6">
              <b-form-group label="Postal Code">
                <b-form-input
                  id=""
                  type="text"
                  placeholder="Enter Postal Code"
                ></b-form-input>
              </b-form-group>
            </div>
            <div class="col-md-12">
              <b-form-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="Ownership and Encumbrances Report"
                    >Ownership and Encumbrances Report</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="Chain of Title">Chain of Title</b-form-checkbox>
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="Open Mortgage Search"
                    >Open Mortgage Search</b-form-checkbox
                  >
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="Owner Verification">Owner Verification</b-form-checkbox>
                </b-form-checkbox-group>
                <b-form-checkbox-group>
                  <b-form-checkbox value="Specific Document Retrieval"
                    >Specific Document Retrieval</b-form-checkbox
                  >
                </b-form-checkbox-group>
              </b-form-group>
            </div>
            <div class="col-md-6">
              <b-form-group label="File Date">
                <b-form-input
                  id=""
                  type="text"
                  placeholder="Enter File Date"
                ></b-form-input>
              </b-form-group>
            </div>
            <div class="col-md-6">
              <b-form-group label="Filing/Instrument Number">
                <b-form-input
                  id=""
                  type="text"
                  placeholder="Enter Filing/Instrument Number"
                ></b-form-input>
              </b-form-group>
            </div>
          </div>
        </div>
      </div>
      <!-- end of row real_property_service -->
      <div class="row special_instruction">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <b-form-group label="Special Instructions">
                <b-form-textarea
                  id=""
                  placeholder="Enter something..."
                  rows="3"
                  max-rows="6"
                ></b-form-textarea>
              </b-form-group>
              <p>You will receive an email confirmation after submitting your order. A Service Representative will contact you if additional information is needed in order to process your request. Thank you!</p>
              <b-button type="submit" class="submit_btn" :disabled="submitStatus === 'PENDING'" variant="primary">Submit</b-button>
              <p class="typo__p" v-if="submitStatus === 'OK'">Thanks for your submission!</p>
              <p class="typo__p" v-if="submitStatus === 'ERROR'"></p>
              <p class="typo__p" v-if="submitStatus === 'PENDING'">Sending...</p>
            </div>
          </div>
        </div>
      </div>
    </b-form>
    <div class="row footer">
      <div class="col-md-12 text-center">
          <p>CLAS Information Services &copy; 2021</p>
          <a href="#">Disclaimer </a>
          <a>|</a>
          <a href="#">Term Of Use</a>
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios'
import { required, minLength,email,maxLength,numeric,alpha } from 'vuelidate/lib/validators'
export default ({
  name: 'AddRemove',
  data()
  {
    return {
      show: true,
      checked: '',
      inputs: [
            {
                service_name: ''
            }
        ],
         inputs1: [
            {
                service_name1: ''
            }
        ],
        name: '',
        lastname: '',
        company_name: '',
        email: '',
        mobile: '',
        address: '',
        city: '',
        state: '',
        country: '',
        postal_code: '',
        clas_acount_number:'',
        refernce_number:'',
        billing_information_first_name:'',
        billing_information_last_name:'',
        billing_information_email:'',
        billing_information_mobile:'',
        billing_information_address:'',
        billing_information_city:'',
        billing_information_state:'',
        billing_information_country:'',
        billing_information_postal_code:'',
        submitStatus: null,
        isShowing:true,
    }
  }, 
  validations: {
     inputs: {
      required,
      $each: {
        service_name: {
          required,
          minLength: minLength(2)
        }
      }
    },inputs1: {
      required,
      $each: {
        service_name1: {
          required,
          minLength: minLength(2)
        }
      }
    },
    name: {
      required,
      
    },
    lastname:{
      required,
     
    },
    company_name:{
      required,
    },
    email:{
      required,
      email:email
    },
    mobile:{
      required,
      minLength:minLength(10),
      maxLength:maxLength(12),
      numeric
    },
    address:{
      required
    },
    city:{
      required,
    },
    state:{
      required
    },
    country:{
      required,
    },
    postal_code:{
      required,numeric,
     
      
    },
    billing_information_state:{
      required,

    },
    billing_information_city:{
      required,
    },
    billing_information_email:{
      required,
      email:email,
    },
    billing_information_mobile:{
      required,
      minLength:minLength(10),
      maxLength:maxLength(12),
      numeric

    },
    billing_information_address:{
      required,
    },
    billing_information_last_name:{
      required,

    },
    billing_information_first_name:{
      required,alpha
    },
    billing_information_postal_code:{
       required,numeric,
     
     
    },
    billing_information_country:{
      required
    }
  },
   mounted () {
            this.get_place_an_order()
    },
  methods: {
    addInput() {
        this.inputs.push({ service_name: '' });
    },
     check: function(value) {
      //console.log(event+''+value)
     if (value=='true') {
       this.billing_information_city=this.city;
       this.billing_information_email= this.email;
       this.billing_information_state= this.state;
       this.billing_information_mobile= this.mobile;
       this.billing_information_address = this.address;
       this.billing_information_country = this.country;
       this.billing_information_last_name = this.lastname;
       this.billing_information_first_name= this.name;
       this.billing_information_postal_code= this.postal_code;
       this.isShowing=false;
      }
      else
      {
         this.isShowing=true;
         this.billing_information_city='';
       this.billing_information_email='';
       this.billing_information_state= null;
       this.billing_information_mobile= '';
       this.billing_information_address = '';
       this.billing_information_country = '';
       this.billing_information_last_name = '';
       this.billing_information_first_name='';
       this.billing_information_postal_code= '';
      }
    },
    removeInput() {
      this.inputs.pop();
    },
     addInput1() {
        this.inputs1.push({ service_name1: '' });
    },
    removeInput1() {
      this.inputs1.pop();
    },
    orderplace:async  function(){
      this.$v.$touch()
      if(this.$v.$invalid){
          this.submitStatus = 'ERROR'
      }else{
           this.submitStatus = 'PENDING'
         setTimeout(() => {
          var  parameters = {


                first_name:this.name,
                email:this.email,
                mobile:this.mobile,
                company_name:this.company_name,
                lastname:this.lastname,
                address:this.address,
                city:this.city,
                state:this.state,
                country:this.country,
                phone:this.phone,
                postal_code:this.postal_code,
                target_name:this.inputs,
                location:this.inputs1,
                refernce_number:this.refernce_number,
                clas_acount_number:this.clas_acount_number,
                billing_information_first_name:this.billing_information_first_name,
                billing_information_city:this.billing_information_city,
                billing_information_email:this.billing_information_email,
                billing_information_state:this.billing_information_state,
                billing_information_mobile:this.billing_information_mobile,
                billing_information_address:this.billing_information_address,
                billing_information_last_name:this.billing_information_last_name,
                billing_information_country:this.billing_information_country,
                billing_information_postal_code:this.billing_information_postal_code
               

            }

            axios.post('api/place_an_order', parameters ).then((response)=>{
              if(response.data.status_code==200){
                 this.$toast.success({message:response.data.message}).then(location.replace("/placeorder"));
                 /*this.submitStatus = 'OK'
                 this.refernce_number='';
                  this.clas_acount_number='';
                  this.billing_information_first_name='';
                  this.billing_information_city='';
                  this.billing_information_email='';
                  this.billing_information_state='';
                  this.billing_information_mobile='';
                  this.billing_information_address='';
                  this.billing_information_last_name='';
                  this.billing_information_country='';
                  this.billing_information_postal_code='';*/
                
              }
              else if(response.data.record.status_code==403)
                    {

                         this.$toast.error({message:response.data.record.message})
                          localStorage.clear();
                            location.replace("/");
                      
                    }
                     else if(response.data.record.status_code==500)
                    {

                         this.$toast.error({message:response.data.record.message})
                          //localStorage.clear();
                            //location.replace("/");
                      
                    }
            },
            (error)=>{
                 console.log(error);
              }

              
            )
           
        }, 500)
      }
    },
    selectAll:async function(){
           alert('isSelected');
        /* if (event.target.checked) {
        }*/ 
       },
    get_place_an_order:async function(){

            var userid= localStorage.getItem('userid',)
                 axios.post('/api/get_details_place_an_order',{id:userid  
              }).then((response) => {
                    if(response.data.record.status_code==200){
                        var name_arr=response.data.record.message.fullName.split(' ');
                        this.name= name_arr[0];
                        this.lastname= name_arr[1];
                        this.company_name= response.data.record.message.company_name

                        this.mobile= response.data.record.message.phone
                        this.email= response.data.record.message.emailAddress
                        this.address= response.data.record.message.address
                        this.city= response.data.record.message.city
                        this.state = response.data.record.message.state
                        this.country= response.data.record.message.country
                        this.postal_code=response.data.record.message.postal_code
                       
                    }
                    else if(response.data.record.status_code==202)
                    {

                      
                       var  innerHTML= response.data.record.message
                           
                            for (var i = 0; i < innerHTML.length; i++) {
                                
                                 this.$toast.error({message:innerHTML[i]})
                                
                            }

                    }
                     else if(response.data.record.status_code==500)
                    {
                            this.$toast.error({message:response.data.record.message})
                                
                      
                    }
                    else if(response.data.record.status_code==403)
                    {

                         this.$toast.error({message:response.data.record.message})
                          localStorage.clear();
                            location.replace("/");
                      
                    }
                    ///console.log(response)
              },

              (error)=>{
                 console.log(error);
              }

              )
    }
  }
});
</script>
