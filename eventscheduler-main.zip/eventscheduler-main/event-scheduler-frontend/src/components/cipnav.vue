<template>
    <div class="col-lg-12">
        <div class="mainnav">
            <div class="floatleft">
                <b-nav>
                    <b-nav-item-dropdown class="togglemenu">
                    <template #button-content>
                       <b-icon icon="text-left" aria-hidden="true" v-on:click="openMenu()"></b-icon>
                    </template>
                    <span>What would you like to do?</span> 
                    <b-dropdown-item @click="validateLogin('/dashboard')">Access Dashboard</b-dropdown-item>

                    <b-dropdown-item @click="validateLogin('/Userprofile')" > <b-avatar variant="success" icon="people-fill" class="mr-3"></b-avatar> Users </b-dropdown-item>

                    <b-dropdown-item  @click="validateLogin('/errorlog')" ><b-icon-layout-text-sidebar-reverse></b-icon-layout-text-sidebar-reverse> Error Log </b-dropdown-item>
                    <b-dropdown-item  @click="validateLogin('/historylog')" ><b-icon-layout-text-sidebar-reverse></b-icon-layout-text-sidebar-reverse> History Log </b-dropdown-item>

                    <!-- <b-dropdown-item @click="validateLogin('/placeorder')"><b-icon-cart-plus-fill></b-icon-cart-plus-fill> Place an Order</b-dropdown-item> -->

                    <!-- <b-dropdown-item @click="validateLogin(firsturl)"><b-icon-search></b-icon-search> Perform a UCC Search</b-dropdown-item>

                    <b-dropdown-item  @click="validateLogin(secondurl)"><b-icon-archive-fill></b-icon-archive-fill> Access UCC eZFILE PRO</b-dropdown-item> -->

                    <!-- <b-dropdown-item  @click="validateLogin(thirdurl)">Access you CLAS Infobox</b-dropdown-item>

                    <b-dropdown-item @click="validateLogin('https://clasinfopro.clasinfo.com/paymentcenter')" ><b-icon-credit-card></b-icon-credit-card> Pay an Invoice</b-dropdown-item> -->

                    </b-nav-item-dropdown>
                    <b-nav-item @click="validateLogin('/dashboard')">Event Scheduler</b-nav-item>
                </b-nav>
            </div>
            <div class="floatright">
                <b-nav>
                    <b-nav-item-dropdown right class="profilemenu" v-if="checkLogin() === true">
                    <template #button-content>
                         {{ username }}
                    </template>
                    <b-dropdown-item href="#">
                        <div class="profilesec">
                            <div class="profileicon">
                                <b-icon-person-fill></b-icon-person-fill>
                            </div>
                            <div class="profiledetail">
                                <span class="name">{{ fullname }}</span>
                                <span>{{ emailAddress }}</span>
                                <span>{{ phone }}</span>
                            </div>
                        </div>
                    </b-dropdown-item>
                    
                  
                    <b-dropdown-item href="/Userprofile"><b-icon-bag></b-icon-bag> My profile</b-dropdown-item>
                    <b-dropdown-item href="#" @click="signOut"><b-icon-bag></b-icon-bag> Sign out</b-dropdown-item>
                    </b-nav-item-dropdown>
                </b-nav>
            </div>
            <div class="clear"></div>
        </div>
    </div>
</template>

<script>

export default {
    data()
    {
        const tempurl = location.pathname;
        //console.log(tempurl);
        if(tempurl !== '/' && tempurl !== '/forgotpassword' && tempurl !== '/resetpassword'){
                if(localStorage.getItem('token') === undefined || localStorage.getItem('token') === '' || localStorage.getItem('token')=== null){
                   localStorage.removeItem("username");
                   localStorage.removeItem("fullname");
                   localStorage.removeItem("emailAddress");
                   localStorage.removeItem("phone");
                   localStorage.removeItem("userid");
                   localStorage.removeItem("securityalert");
                   
                   
                    window.location.href = '/';
                   // location.replace('');
                }
            }else{
               
                if(localStorage.getItem('token') !== undefined && localStorage.getItem('token') !== '' && localStorage.getItem('token')!== null){
                     window.location.href = '/dashboard';
                    //location.replace("/dashboard");
                }
            }
        return {
            username : localStorage.getItem('username'),
            fullname : localStorage.getItem('fullname'),
            emailAddress : localStorage.getItem('emailAddress'),
            phone : localStorage.getItem('phone'),
            firsturl:'',
            secondurl:"",
            thirdurl:"",
        };
    },
     mounted(){
        var websitelinkid=localStorage.getItem('websitelinkid')
        var bookkeepingid=localStorage.getItem('bookkeepingid')
            this.firsturl='http://searching.clasinfo.com/passthru?vtech='+websitelinkid+'&vtget='+bookkeepingid+''
            this.secondurl='http://www.uccezfile.com/passthru?vtech='+websitelinkid+'&vtget='+bookkeepingid+''
            ////this.thirdurl='#'
            
    },

    methods: {
        signOut(){
            //localStorage.clear();
                   localStorage.removeItem("token");
                   localStorage.removeItem("username");
                   localStorage.removeItem("fullname");
                   localStorage.removeItem("emailAddress");
                   localStorage.removeItem("phone");
                   localStorage.removeItem("userid");
                   localStorage.removeItem('websitelinkid');
                   localStorage.removeItem('bookkeepingid');
                   localStorage.removeItem("securityalert");
            location.replace("/");
        },
        checkLogin(){
            return !(localStorage.getItem('token') === undefined || localStorage.getItem('token') === '' || localStorage.getItem('token')=== null);
        },
        validateLogin(url){
            if(location.pathname !== '/'){

                if(this.checkLogin()){
                    //localStorage.clear();
                    if(url==='/dashboard')
                    {
                        location.replace(url);
                    }
                    else
                    {
                         location.replace(url);
                    }
                }else{
                    location.replace("/");
                }
            }
        }, 
        openMenu() {
          let row = document.querySelectorAll(".container .row");
          console.log(row);
          for (let i = 0; i < row.length; i++) {
            row[i].classList.add("open_menu");
          }
    }
    }
}

</script>