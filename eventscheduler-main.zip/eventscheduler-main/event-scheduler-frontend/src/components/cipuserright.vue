<template>
	<div class="row">
	   <div class="usermain">
		<div class="col-sm-6">
			 <b-form @submit.prevent="add_user" id="form">
                   <div class="col-md-12">
                       
                        <b-card bg-variant="light">
                            <h2>User Profile</h2>
                            <div class="secbrder">
                            <b-form-group
                                label="User Name"
                                label-for="user-name"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-name" disabled v-model="username" type="text" required></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label=" Full Name  "
                                label-cols-sm="2"
                                label-align-sm="right"
                               
                            >
                               <b-form-input id="full_name" disabled type="text" v-model="fullName" required ></b-form-input>
                            </b-form-group>

                            <b-form-group
                                label="Company"
                                label-for="user-company"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-company" disabled type="text" v-model="company" required></b-form-input>
                            </b-form-group>

                            <b-form-group
                                label="Email"
                                label-for="user-email"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-email" disabled v-model="email" type="email" required></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label=" Alternate Email  "
                                label-cols-sm="2"
                                label-align-sm="right"
                              
                            >
                               <b-form-input id="alt_name_email" type="email"  v-model="alt_name_email" disabled></b-form-input>
                            </b-form-group>
                             <b-form-group
                                label="Phone "
                                label-cols-sm="2"
                                label-align-sm="right"
                                
                            >
                               <b-form-input id="phone" disabled type="number" v-model="phone" required></b-form-input>
                            </b-form-group>
                            <b-form-group
                                label=" Cell Phone "
                                label-cols-sm="2"
                                label-align-sm="right"
                                
                            >
                               <b-form-input id="cell_phone"  disabled type="number" v-model="cell_phone" ></b-form-input>
                            </b-form-group>

                            <b-form-group
                                label="Password"
                                label-for="user-password"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-input id="user-password" disabled v-model="password" type="password" required></b-form-input>
                            </b-form-group>
                             <b-form-group
                                label="Address"
                                label-for="address"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <b-form-textarea
                                      id="address"
                                      v-model="address"
                                      placeholder="Enter something..."
                                      rows="3"
                                      max-rows="6"
                                      disabled
                                      
                                ></b-form-textarea>
                            </b-form-group>

                            <b-form-group
                                label="Security role"
                                label-for="security-role"
                                label-cols-sm="2"
                                label-align-sm="right"
                            >
                                <select v-model="selected" class="form-control" disabled>
                                      <option v-for="option in options"  v-bind:value="option.value">
                                        {{ option.text }}
                                      </option>
                                </select>
                            </b-form-group>
                            <div class="clear"></div>
                            </div>
                        </b-card>
                   </div>
              </b-form>
		</div>
		<div class="col-sm-6">
	     <b-card bg-variant="light">
	         <div class="row adduser">
	             <div class="col-sm-4">
	            <h2>ABC Company users</h2>
	         </div>
	         <div class="col-sm-2">
	           	<a href="/adduser"> <b-icon-plus-circle></b-icon-plus-circle>
	            <span>Add user</span></a>
	         </div>
	         <div class="col-sm-2">
	           <a href="/edituser"> <b-icon-pencil></b-icon-pencil>
	            <span>Edit user</span></a>
	         </div>
	         <div class="col-sm-2">
	            <b-icon-person-x></b-icon-person-x>
	            <span>Disable user</span>
	         </div>
	         <div class="col-sm-2">
	            <b-icon-x></b-icon-x>
	            <span>Remove user</span>
	         </div>
	         </div>
	        <div class="secbrder">
	            <div id="table">
	                 <b-form-input v-model="keyword" placeholder="Search"></b-form-input>
	                 <b-table striped  :items="items"  @row-clicked="showdetails">
		                 
	                   
	                 </b-table>
	            </div>
	        </div>
	     </b-card>
     </div>
		</div>
	</div>
     
</template>
<script>

import axios from 'axios'
export default({
	el: '#table',
	data () {
		return {
		    username:'',
	        email:'',
	        password:'',
	        company:'',
	        address:'',
	        phone:'',
	        cell_phone:'',
	        alt_name_email:'',
	        fullName:'',
	         selected: 'A',
            options: [
              { text: 'Guest', value: 'Guest' },
              { text: 'User', value: 'User' },
              { text: 'Company User', value: ' Company s User' },
              { text: 'Organization  User', value: ' Organization s User' }
            ],
			keyword: '',
			dataArray: [],
			fields: [
				{key: 'fullName', label: 'First name', sortable: true},
				{key: 'emailAddress', label: 'Email', sortable: true},
				{key: 'id', label: 'Id', sortable: true},
				{key: 'phone', label: 'Phone', sortable: true}
			]
		}
	}, 
	mounted () {
    		this.get_user()
	},
	computed: {
		items () {
			return this.keyword
				? this.dataArray.filter(item => item.fullName.includes(this.keyword)|| item.emailAddress.includes(this.keyword) || item.id.includes(this.keyword) ||item.phone.includes(this.keyword) )
				: this.dataArray
		}
	},
	methods:{
	async get_user(){

              axios.get('/api/get_users', {
               
            }).then((response) => {
            	if(response.data.status=="success"){
            		this.dataArray=response.data.message;
            	}
                ///console.log(response);
            },(error) => {
                console.log(error);
            });
       
         
      },
     showdetails(data) {
   			 if(data.id)
   			 {
   			 	localStorage.setItem('edituser',data.id)
   			 	 axios.post('/api/showprofile',{id:data.id               
		            }).then((response) => {
		            	if(response.data.record.status_code==200){
		            		
		            	}else if(response.data.record.status_code==500){
		            		  this.$toast.success({message:response.data.record.message})
                        		
		            	}
		                ///console.log(response);
		            },(error) => {
		                console.log(error);
		            });
   			 }
  		}
	}
})
</script>