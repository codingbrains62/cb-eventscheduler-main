<template>
     <b-card bg-variant="light">
         <div class="row adduser">
             <div class="col-sm-4">
            <h2>ABC Company users</h2>
         </div>
         <div class="col-sm-2">
            <b-icon-plus-circle></b-icon-plus-circle>
            <span>Add user</span>
         </div>
         <div class="col-sm-2">
            <b-icon-pencil></b-icon-pencil>
            <span>Edit user</span>
         </div>
         <div class="col-sm-2">
            <b-icon-person-x></b-icon-person-x>
            <span>Disable user</span>
         </div>
         <div class="col-sm-2">
            <b-icon-x></b-icon-x>
            <span>Remove user</span>
         </div>
         </div>
        
        <div class="secbrder">
            <div id="table">
                 <b-form-input v-model="keyword" placeholder="Search"></b-form-input>
                 <b-table striped hover :items="items"></b-table>
            </div>
        </div>
     </b-card>
</template>

<script>
export default({
	el: '#table',
	data () {
		return {
			keyword: '',
			dataArray: [
				{ firstname: 'John', email: 'johndoe@example.com'  },
				{ firstname: 'Jane', email: 'janedoe@example.com'  },
				{ firstname: 'John', email: 'johndoo@example.com'  },
				{ firstname: 'Jane', email: 'janedoo@example.com'  }
			],
			fields: [
				{key: 'firstname', label: 'First name', sortable: true},
				{key: 'email', label: 'Email', sortable: true}
			]
		}
	},
	computed: {
		items () {
			return this.keyword
				? this.dataArray.filter(item => item.firstname.includes(this.keyword)|| item.email.includes(this.keyword))
				: this.dataArray
		}
	}
})
</script>