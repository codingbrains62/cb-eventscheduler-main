/**
 * Route Mappings
 * (sails.config.routes)
 *
 * Your routes tell Sails what to do each time it receives a request.
 *
 * For more information on configuring custom routes, check out:
 * https://sailsjs.com/anatomy/config/routes-js
 */

module.exports.routes = {

  /***************************************************************************
  *                                                                          *
  * Make the view located at `views/homepage.ejs` your home page.            *
  *                                                                          *
  * (Alternatively, remove this and add an `index.html` file in your         *
  * `assets` directory)                                                      *
  *                                                                          *
  ***************************************************************************/

  '/': { view: 'pages/login' },
  'POST /login': 'validate-login',
  'POST /reset_password': 'reset-login',
  'POST /add_user': 'add-client-user',
  'POST /edit_user': 'udpate-client-user',
  
  'POST /forget_password': 'forget-password',

  'GET /forget_password_link/:tokan': 'forget-password-link',
  ///'GET /forget_password_link/:tokan': 'Forgetpassword1Controller.forget_password_link',
  

  ///'POST /forget_password': 'Forgetpassword1Controller.forget_password',
  ///'POST /update_password': 'Forgetpassword1Controller.update_password',


  /***************************************************************************
  *                                                                          *
  * More custom routes here...                                               *
  * (See https://sailsjs.com/config/routes for examples.)                    *
  *                                                                          *
  * If a request to a URL doesn't match any of the routes in this file, it   *
  * is matched against "shadow routes" (e.g. blueprint routes).  If it does  *
  * not match any of those, it is matched against static assets.             *
  *                                                                          *
  ***************************************************************************/


};
