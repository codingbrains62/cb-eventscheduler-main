module.exports.email = {
 service: "Mailgun",
 auth: {
         user: "postmaster@sandboxf9192e8ff4bd4310b5cc9ae7df55f6e5.mailgun.org", 
         pass: "e28670f5dd5a3e272d4b7a1b98260d88-aff8aa95-bdffbd4a"
 },
 templateDir: "api/emailTemplates",
 from: "info@mycompany.com",
 testMode: false,
 //ssssl: true
}///y+j;M47cZ%#D4uX