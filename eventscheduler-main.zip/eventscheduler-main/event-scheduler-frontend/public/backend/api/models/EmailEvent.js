/**
 * EmailEvent.js
 *
 * @description :: A model definition.  Represents a database table/collection/etc.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 
    //  ╔═╗╦═╗╦╔╦╗╦╔╦╗╦╦  ╦╔═╗╔═╗
    //  ╠═╝╠╦╝║║║║║ ║ ║╚╗╔╝║╣ ╚═╗
    //  ╩  ╩╚═╩╩ ╩╩ ╩ ╩ ╚╝ ╚═╝╚═╝

    description: {
      type: 'string',
      required: true,
      description: 'A longer, full-sentence description of the EmailEvent that occured.'
    },

    actorUserId: {
      type: 'number',
      description: 'This is not an association-- it is another copy of the user id,  in case the user is deleted.'
    },

    actorDisplayName: {
      type: 'string',
      required: true
    },

    category: {
      type: 'string',
      description: 'A special, generic category for this kind of EmailEvent event.',
      isIn: [
        'Client',
        'Vendor',
        'Delivery',
        'Other',
      ],
      defaultsTo: 'Other',
    },

 

    //  ╔═╗╔╦╗╔╗ ╔═╗╔╦╗╔═╗
    //  ║╣ ║║║╠╩╗║╣  ║║╚═╗
    //  ╚═╝╩ ╩╚═╝╚═╝═╩╝╚═╝


    //  ╔═╗╔═╗╔═╗╔═╗╔═╗╦╔═╗╔╦╗╦╔═╗╔╗╔╔═╗
    //  ╠═╣╚═╗╚═╗║ ║║  ║╠═╣ ║ ║║ ║║║║╚═╗
    //  ╩ ╩╚═╝╚═╝╚═╝╚═╝╩╩ ╩ ╩ ╩╚═╝╝╚╝╚═╝

    client: { model: 'Client', description: 'The client this EmailEvent is related to, if relevant.' },
    
  },

};

