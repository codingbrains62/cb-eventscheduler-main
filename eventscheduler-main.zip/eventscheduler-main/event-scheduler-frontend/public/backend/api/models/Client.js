/**
 * Client.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */
var bcrypt = require('bcrypt-nodejs');


module.exports = {

  attributes: {

    //  ╔═╗╦═╗╦╔╦╗╦╔╦╗╦╦  ╦╔═╗╔═╗
    //  ╠═╝╠╦╝║║║║║ ║ ║╚╗╔╝║╣ ╚═╗
    //  ╩  ╩╚═╩╩ ╩╩ ╩ ╩ ╚╝ ╚═╝╚═╝
    

    username: {
      type: 'string',
      required: true,
      isEmail: true,
      maxLength: 200,
      example: 'mary.sue@example.com'
    },

    password: {
      type: 'string',
      required: true,
      description: 'Securely hashed representation of the user\'s login password.',
      protect: true,
      example: '2$28a8eabna301089103-13948134nad'
    },

    tosAcceptedByIp: {
      type: 'string',
      description: 'The IP (ipv4) address of the request that accepted the terms of service.',
      extendedDescription: 'Useful for certain types of businesses and regulatory requirements (KYC, etc.)',
      moreInfoUrl: 'https://en.wikipedia.org/wiki/Know_your_customer'
    },

    lastSeenAt: {
      type: 'number',
      description: 'A JS timestamp (epoch ms) representing the moment at which this user most recently interacted with the backend while logged in (or 0 if they have not interacted with the backend at all yet).',
      example: 1502844074211
    },

    SecurityLevel: {
      type: 'string',
      required: false,
      description: 'Related to how much data the user has access to possible values: Guest, User, CompanyUser, OrganizationalUser, PLAdmin, GlobalAdmin, and Disabled ',
      maxLength: 120,
      example: 'User'
    },
    
    fullName: {
      type: 'string',
      required: true,
      description: 'Full representation of the person\'s name.',
      maxLength: 120,
      example: 'Mary de Sue van der McHenst'
    },

    emailAddress: {
      type: 'string',
      required: true,
      isEmail: true,
      maxLength: 200,
      example: 'mary.sue@example.com'
    },

    alternateEmailAddress: {
      type: 'string',
      isEmail: true,
      maxLength: 200,
      example: 'mary.sue@example.com'
    },

    mandate: {
      description: 'The noun that best describes this person\'s professional title or duties, especially in connection with how they use CLAS\'s products and services.',
      extendedDescription: 'We use the word "mandate" here to capture the intersection between a client\'s professional title at their organization and the specific ways they interact with us here at CLAS.',
      type: 'string',
      required: true,
      isIn: [
        'Corporate',
        'Finance',
        'Intellectual property',
        'Litigation',
        'Real estate',
        'Other',
        'General Counsel',
      ]
    },

    phone: {
      type: 'string',
      description: 'This person\'s direct phone number at work, if known.',
      extendedDescription: 'Might be a Google Voice number, a home office, or a direct line to this person\'s desk at their office (in which case this includes the extension, if appropriate.)',
      example: '(512) DITTETI ext 123'
    },

    cellPhone: {
      type: 'string',
      description: 'This person\'s personal cell phone number, if known.',
      example: '(512) 348-8384'
    },

    isOnHold: {
      type: 'boolean',
      description: 'A flag indicating whether this client has been "disabled" and can no longer be added to orders.',
    },

    isDisabled: {
      type: 'boolean',
      description: 'A flag indicating whether this client has been "disabled" and can no longer be added to orders.',
    },

    isDeleted: {
      type: 'boolean',
      description: 'A flag that, when set, indicates that this client is no longer active.',
      defaultsTo: false
    },

    bookkeepingId: {
      type: 'string',
      description: 'The billing identifier (aka "account number") representing this client in our 3rd party accounting/bookkeeping system.',
      example: '38-23825'
    },

    perInvoiceMax: {
      type: 'number',
      description: 'The maximum total (USD) that should generally not be exceeded for a single invoice for this client.',
    },

    ebilling: {
      type: 'boolean',
      description: 'A flag indicating whether this client is ebilling client or not.',
    },

    alwayschargecc: {
      type: 'boolean',
      description: 'A flag indicating whether this client has chosen to always be charged via credit card.',
    },

    
    isonhubspot: {
      type: 'boolean',
      description: 'A flag indicating whether this client is on hubspot.',
    },

    HubspotClientLink: {
      type: 'string',
      description: 'The hubspot id indicating whether this client is on hubspot.',
      example: '38-23825'
    },
     

    //  ╔═╗╔╦╗╔╗ ╔═╗╔╦╗╔═╗
    //  ║╣ ║║║╠╩╗║╣  ║║╚═╗
    //  ╚═╝╩ ╩╚═╝╚═╝═╩╝╚═╝
    // N/A

    //  ╔═╗╔═╗╔═╗╔═╗╔═╗╦╔═╗╔╦╗╦╔═╗╔╗╔╔═╗
    //  ╠═╣╚═╗╚═╗║ ║║  ║╠═╣ ║ ║║ ║║║║╚═╗
    //  ╩ ╩╚═╝╚═╝╚═╝╚═╝╩╩ ╩ ╩ ╩╚═╝╝╚╝╚═╝
    billingAccount: {
      model: 'BillingAccount',
      required: true
    }
    ,

   createdBy: {
      type:'number',
      //model: 'User',
      description: 'The ID of the staff member .'
    }

  },
     customtoJSON:function(){
    return __dirname.omit(this,['password'])
  },

    ///autoPK : false,
     beforeCreate: function (user, cb) {


    if (user.password) {
      bcrypt.genSalt(10, function (err, salt) {




        bcrypt.hash(user.password, salt,null, function (err, hash) {
          if (err) {
        ////    console.log(err);
            cb(err);
          } else {
    ////  console.log('bcrypt'+hash)
            user.password = hash;
           ////console.log("saving data" + user.password);
           return cb();
          }
        });
      });
    }else{
     return cb();
    }//
  },
   beforeUpdate: function (user, cb) {


    if (user.password) {
      bcrypt.genSalt(10, function (err, salt) {




        bcrypt.hash(user.password, salt,null, function (err, hash) {
          if (err) {
        ////    console.log(err);
            cb(err);
          } else {
    ////  console.log('bcrypt'+hash)
            user.password = hash;
           ////console.log("saving data" + user.password);
           return cb();
          }
        });
      });
    }else{
     return cb();
    }//
  }

};

