/**
 * Note.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {

    //  ╔═╗╦═╗╦╔╦╗╦╔╦╗╦╦  ╦╔═╗╔═╗
    //  ╠═╝╠╦╝║║║║║ ║ ║╚╗╔╝║╣ ╚═╗
    //  ╩  ╩╚═╩╩ ╩╩ ╩ ╩ ╚╝ ╚═╝╚═╝
    authorDisplayName: {

      type: 'string',
      required: true,
      description: 'Cached full name of the author, in case the original user record is later destroyed.',
    
    },

    description: {
      type: 'string',
      required: true,
      description: 'The note text.',
    },

    isBusinessComment: {
      type: 'boolean',
      description: 'A flag for client notes to indicate whether this should be grouped into the \'business comments\' notes section.'
    },

    audience: {
      type: 'string',
      description: 'String of audience for note with comma delimiter.'
    },

    //  ╔═╗╔╦╗╔╗ ╔═╗╔╦╗╔═╗
    //  ║╣ ║║║╠╩╗║╣  ║║╚═╗
    //  ╚═╝╩ ╩╚═╝╚═╝═╩╝╚═╝
    // N/A

    //  ╔═╗╔═╗╔═╗╔═╗╔═╗╦╔═╗╔╦╗╦╔═╗╔╗╔╔═╗
    //  ╠═╣╚═╗╚═╗║ ║║  ║╠═╣ ║ ║║ ║║║║╚═╗
    //  ╩ ╩╚═╝╚═╝╚═╝╚═╝╩╩ ╩ ╩ ╩╚═╝╝╚╝╚═╝
    client: {
      model: 'Client',
      description: 'The client this note is attached to, if it is a client note or business comment.'
    },

    billingaccount: {
      model: 'billingaccount',
      description: 'The account this note is attached to, if it is a account note.'
    },

    org: {
      model: 'Org',
      description: 'The organization this note is attached to, if it is a company note.'
    },   

    createdBy: {
      type:'number',
      //model: 'User',
      description: 'The ID of the staff member who left this note.'
    }

  },

};

