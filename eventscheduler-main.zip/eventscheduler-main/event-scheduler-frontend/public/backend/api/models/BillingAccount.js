/**
 * BillingAccount.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {

    //  ╔═╗╦═╗╦╔╦╗╦╔╦╗╦╦  ╦╔═╗╔═╗
    //  ╠═╝╠╦╝║║║║║ ║ ║╚╗╔╝║╣ ╚═╗
    //  ╩  ╩╚═╩╩ ╩╩ ╩ ╩ ╚╝ ╚═╝╚═╝
    isInternational: {
      type: 'boolean',
      description: 'Whether this billing account is located outside of the USA.',
    },

    addressPart1: {
      type: 'string',
      description: 'The street address for this account (if located in USA, otherwise… who knows?)',
      example: '4608 Parkcrest Dr'
    },

    addressPart2: {
      type: 'string',
      description: 'The (optional) building/suite number for this account (if located in USA, otherwise… who knows?)',
      example: 'Suite 200'
    },

    addressPart3: {
      type: 'string',
      description: 'The city for this account (if located in USA, otherwise… who knows?)',
      example: 'Austin'
    },

    addressPart4: {
      type: 'string',
      description: 'The state/territory for this account (if located in USA, otherwise… who knows?)',
      example: 'Texas'
    },

    addressPart5: {
      type: 'string',
      description: 'The postal code for this account (if located in USA, otherwise… who knows?)',
      example: '78751'
    },

    phone: {
      type: 'string',
      description: 'The (probably shared) general office phone number for this billing account.',
      example: '(512) DITTETI'
    },

    fax: {
      type: 'string',
      description: 'The (probably shared) fax number for this billing account.',
      example: '(512) 348-8384'
    },

    bookkeepingId: {
      type: 'string',
      description: 'The billing identifier (aka "account number") representing this account in our 3rd party accounting/bookkeeping system.',
      example: '38-23825'
    },

    feeSchedule: {
      type: 'string',
      defaultsTo: 'Retail 1',
      isIn: [
        'Retail 1',
        'Retail 2',
        'Retail 3',
        'Retail 4',
        'One Rate 1',
        'One Rate 2',
        'One Rate 3',
        'One Rate 4',
        'Wholesale 1',
        'Wholesale 2',
        'Wholesale 3',
        'Wholesale 4',
      ]
    },

    isMonthlyBillingSummaryEnabled: {
      type: 'boolean',
      description: 'A flag indicating whether a monthly billing summary should be generated for this account.'
    },

    isEBilling: {
      type: 'boolean',
      description: 'A flag indicating whether a monthly billing summary should be generated for this account.'
    },

    hubspotaccountlink: {
      type: 'string',
      description: 'The hubspotaccountlink identifier (aka "account number") representing this account in our hubspot account.',
      example: '38-23825'
    },

    //  ╔═╗╔╦╗╔╗ ╔═╗╔╦╗╔═╗
    //  ║╣ ║║║╠╩╗║╣  ║║╚═╗
    //  ╚═╝╩ ╩╚═╝╚═╝═╩╝╚═╝
    // N/A


    //  ╔═╗╔═╗╔═╗╔═╗╔═╗╦╔═╗╔╦╗╦╔═╗╔╗╔╔═╗
    //  ╠═╣╚═╗╚═╗║ ║║  ║╠═╣ ║ ║║ ║║║║╚═╗
    //  ╩ ╩╚═╝╚═╝╚═╝╚═╝╩╩ ╩ ╩ ╩╚═╝╝╚╝╚═╝
    org: {
      model: 'Org',
      required: true
    },
  },

};

