/**
 * Org.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {

    //  ╔═╗╦═╗╦╔╦╗╦╔╦╗╦╦  ╦╔═╗╔═╗
    //  ╠═╝╠╦╝║║║║║ ║ ║╚╗╔╝║╣ ╚═╗
    //  ╩  ╩╚═╩╩ ╩╩ ╩ ╩ ╚╝ ╚═╝╚═╝
    name: {
      type: 'string',
      required: true,
      description: 'The organization\'s name (their legal entity name).',
      example: 'Goliath Industries LLC'
    },

    category: {
      description: 'The customer category that best describes this organization\'s relationship with CLAS, especially in terms of their use case for CLAS\'s products and services.',
      type: 'string',
      required: true,
      example: 'Commercial Bank',
      isIn: [
        'ABL/Factor',
        'Accounting firm',
        'Commercial bank',
        'Correspondent',
        'General business',
        'Law firm',
        'Leasing/Financing company',
        'Other',
        'REIT/Development/Title',
      ]
    },


    //  ╔═╗╔╦╗╔╗ ╔═╗╔╦╗╔═╗
    //  ║╣ ║║║╠╩╗║╣  ║║╚═╗
    //  ╚═╝╩ ╩╚═╝╚═╝═╩╝╚═╝


    //  ╔═╗╔═╗╔═╗╔═╗╔═╗╦╔═╗╔╦╗╦╔═╗╔╗╔╔═╗
    //  ╠═╣╚═╗╚═╗║ ║║  ║╠═╣ ║ ║║ ║║║║╚═╗
    //  ╩ ╩╚═╝╚═╝╚═╝╚═╝╩╩ ╩ ╩ ╩╚═╝╝╚╝╚═╝
    
    billingAccounts: { collection: 'BillingAccount', via: 'org', description: 'This organization\'s billing accounts, often corresponding to its different locations.' }
  },

};

