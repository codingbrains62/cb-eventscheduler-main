/**
 * Forget_password1.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

 tableName: 'forget_password',
  attributes: {

     tokan: {
      type: 'string',
      description: 'user verify tokan ',
     
      example: '(512) DITTETI ext 123'
    },

    userid: {
      type: 'number',
      description: 'user id for requestd user id  ',
      example: '(512) 348-8384'
    },

    tokan_status: {
      type: 'boolean',
      description: '1= action and 2 = expired',
    },

    browser: {
      type: 'string',
      description: 'Store browsr details ',
    },

  },

};

