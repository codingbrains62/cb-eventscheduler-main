module.exports.sendWelcomeMail = function(obj) {

    ///console.log(obj.emailAddress)
 sails.hooks.email.send(
 "welcomeEmail", 
 {
 Name: 'gghhhh'
 },
 {
 to: obj.emailAddress,
 subject: "Welcome Email"
 },
 function(err) {console.log(err || "Mail Sent!");}
 )
}