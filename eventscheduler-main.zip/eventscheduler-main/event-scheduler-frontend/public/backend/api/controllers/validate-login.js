var passport = require('passport');
 bcrypt = require('bcrypt'); 

module.exports = {


  friendlyName: 'Validate login',


  description: '',


  inputs: { 
    email: {
      required: true,
     
      type: 'string',
      isEmail: true,
      description: 'The email address for the new account, e.g. m@example.com.',
      extendedDescription: 'Must be a valid email address.',
    },
    password: {
      required: true,
      type: 'string',
      maxLength: 15,
      minLength: 2,
      example: 'passwordlol',
      description: 'The unencrypted password to use for the new account.'
    },

  },

  exits: {
     invalid: {
      statusCode: 409,
      description: ' email and password is required.'
    },
    redirect: {
      responseType: 'redirect'
    },
    somethingHappened: {
         responseType: 'serverError'
   }
  },

 

  fn: async function  (inputs,exits) {



    try{
          var res= this.res;
          var req= this.req;
           user =   await  Client.findOne({'emailAddress':inputs.email});

      
          

        if(!user)
        {
            var noacountuser= {
              status:'error',

              message:'this email address'+inputs.email+' Not found'
            };
           
            //res.forbidden();

            res.json({record:noacountuser});
            return ;
        }
        else
        {


               function compareAsync(param1, param2) {
                  return new Promise(function(resolve, reject) {
                      bcrypt.compare(param1, param2, function(err, res) {
                          if (err) {
                               reject(err);
                          } else {
                               resolve(res);
                          }
                      });
                  });
              }
            const password = await compareAsync(inputs.password, user.password);
                 if(password)
                  {
                      
                    req.session.authenticated= true;

                   req.session.userId= user.id;
                   req.session.username= user.fullName;

                   let lastseen = new Date();

                   res.json({session:req.session})

                await Client.update({'id':user.id},{lastSeenAt: lastseen });

                    var data= {
                      description:'login',
                      actorId:req.session.userId,
                      actorType:'Client',
                      actorDisplayName:req.session.username,
                      category:'Login'
                    }
                      
                    var dataobj = await  HistoricalEvent.create(data).exec(function(err,logs){
                       
                       if(err)
                       {
                         var noacountuser= {
                              status:'error',

                             message:"Something want wrong ",
                            };
                           
                
                          res.json({record:noacountuser});
                       }


                    })
                    var noacountuser= {
                            status:'success',

                           message:'Successfully login Welcome ' + user.fullName,
                          };
                 
                    //// res.json({session:req.session.userId})
                 
                        res.json({record:noacountuser});
                 
                  return ;


                      
                      
                  }
                  else
                  {
                      var noacountuser= {
                        status:'error',

                       message:'invalid user name and password ',
                      };
                     
                      //res.forbidden();
                      res.json({record:noacountuser});
                      return ;

                  }
        }
  

    }
    catch(error)
    {
                     var noacountuser= {
                        status:'error',
                        status_code:500,

                       message:'Internal  Server Error ',
                      };
                     
                     
                      res.json({record:noacountuser});
                      return ;
    }



  




  }



};
