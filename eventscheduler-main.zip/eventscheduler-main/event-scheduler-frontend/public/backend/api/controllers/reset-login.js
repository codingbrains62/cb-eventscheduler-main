module.exports = {


  friendlyName: 'Reset login',


  description: '',


  inputs: {
    password:{
      type:'string',
      required:true
    }

  },


  exits: {
    success:{
      status:'success',
      message:'reset password Successfully  '
    },
    failed:{
       status:'error',
      message:'reset password failed   '
    },
    expired:{
       status:'error',
      message:'Tokan already use please sent again required   '
    },
    servereerrro:{
      status:'error',
      status_code:500,
      message:'Internal serverError  '
    }


  },


  fn:  async function  (inputs,exits) {


    var req= this.req;
    var res= this.res;

   try{

      var tokan_exits = await  Forget_password1.find({ tokan:req.param('tokan'),tokan_status:1 });
        if(tokan_exits.length>0)
        {
               await Client.update({'id':tokan_exits.userid},{password:req.param('password') });
               await Forget_password1.update({'id':tokan_exits.id},{tokan_status:0 });

                var data= {
                      description:'reset password Successfully ',
                      actorId:1,
                      actorType:'Client',
                      actorDisplayName:'username',
                      category:'Login'
                    }
                      
                    var dataobj = await  HistoricalEvent.create(data).exec(function(err,logs){
                       
                       if(err)
                       {
                         
                            failed={
                                   status:'error',
                                  message:'reset password failed '
                                }
                
                          res.json({record:failed});
                       }


                    })

                success={
                    status:'success',
                    message:'reset password Successfully  '
                  }

                res.json({record:success});
        }
        else
        {


           var data= {
                      description:'reset  password  not Successfully ',
                      actorId:1,
                      actorType:'Client',
                      actorDisplayName:'username',
                      category:'Login'
                    }
                      
                    var dataobj = await  HistoricalEvent.create(data).exec(function(err,logs){
                       
                       if(err)
                       {
                         failed={
                           status:'error',
                          message:'reset password failed   '
                        }
                         res.json({record:failed});
                       }


                    })
           
                 expired={
       status:'error',
      message:'Tokan already use please sent again required   '
    }

                res.json({record:expired});
        }

   }catch(error){

    servereerrro={
      status:'error',
      status_code:500,
      message:'Internal serverError  '
    }
     res.json({record:servereerrro});
   }

  },



};
