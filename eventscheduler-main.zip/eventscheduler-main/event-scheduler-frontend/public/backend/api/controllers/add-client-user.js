module.exports = {


  friendlyName: 'Add client user',


  description: 'Add  user information',


 inputs: {

    username:{
      type: 'string',
      required: true,
      
      maxLength: 200,
      example: 'Amit Sharma'
    },
    password:{
       type: 'string',
      required: true,
      description: 'Securely hashed representation of the user\'s login password.',
      protect: true,
      example: '2$28a8eabna301089103-13948134nad'
    }
    ,
     fullName:{
       type: 'string',
      required: true,
      
      maxLength: 200,
      example: 'Amit shaha'
    },

   
    email:{
       type: 'string',
      required: true,
      isEmail: true,
      maxLength: 200,
      example: 'mary.sue@example.com'
    },
    altemail:{
       type: 'string',
      required: true,
      isEmail: true,
      maxLength: 200,
      example: 'mary.sue@example.com'
    },
   
    phone:{
      type: 'string',
      required: true,
      description:'user phone number',
      example:'9145784571'
      
    },
     cellphone:{
      type: 'string',
      required: true,
      description:'user  Cell  phone number',
      example:'9145784571'
      
    }
    ,
    security_Level:{
      type: 'string',
      required: true,
      description:'user  Security Level   ',
      example:'this is lappi'
      
    },

 billingaddressPart1:{
     type: 'string',
      required: true,
      description:'user  Security Level   ',
      example:'this is address 1 - 5 ',

 },
  company_name:{
      type: 'string',
      required: true,
      description:'organization name ',
      example:'this is lappi key '
 }
   

  },


  exits: {
    success:{
      status:200,
      message:'Record has been update successfully '
    },
    failed:{
      status:202,
      message:'Some thing error please try again'
    },
    error:{
      status:404,
      message:'Page Not found '
    }

  },


  fn: async function (inputs,exits) {
    var req=this.req;
    var res=this.res;

   

     try{          



         var orginsert= await Org.create({'name':inputs.company_name,'category':'ABL/Factor'}).fetch();
         var billingaddressPart1 = await BillingAccount.create({'addressPart1':inputs.billingaddressPart1,'org':orginsert.id}).fetch();

         data = {
           username:inputs.username,
           password:inputs.password,
           fullName:inputs.fullName,
           emailAddress:inputs.email,
           alternateEmailAddress:inputs.altemail,
           phone:inputs.phone,
           cellphone:inputs.cellphone,
           SecurityLevel:inputs.security_Level,
           billingAccount:billingaddressPart1.id,
           mandate:'Corporate',
           createdBy:1
          }

         var client = await Client.create(data).exec(function(err,user){
                      if(err){
                        res.json({err:err})
                      }
                  
              var data= {
                      description:'Add user insert Successfully ',
                      actorId:1,
                      actorType:'Client',
                      actorDisplayName:inputs.fullName,
                      category:'Other'
                    }

                      
                    var dataobj =   HistoricalEvent.create(data).exec(function(err,logs){
                       
                       if(err)
                       {
                          res.json({record:err});
                       }
                             success={
                              status:'success',
                              message:'Record has been update successfully '
                            }
                       res.json({record:success})

                    });

                    success={
                      status:200,
                      message:'Record has been update successfully '
                    }
                      res.json({record:success})
         });
         
           
          

     }catch(error){
       success={
      status_code:500,
      status:'error',
      message:'Internal Server Error '
    }
      res.json({record:success})

      
     }

  }


};
