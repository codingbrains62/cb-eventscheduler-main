/**
 * Forgetpassword1Controller
 *
 * @description :: Server-side actions for handling incoming requests.
 * @help        :: See https://sailsjs.com/docs/concepts/actions
 */

module.exports = {

forget_password: function(req, res){


  

        Client.findOne({'emailAddress':req.param('email')}).exec(function(err,user){
               if(err)  {
                    res.send(500, {'err' :err} );
                 }

                if(!user)
                {
                    var noacountuser= [{message:'this email address'+req.param('email')+' Not found'}];
                   
                    //res.forbidden();
                    res.json(202,{error:noaountuser});
                    return ;
                }

                var dataobj={
                    userid:user.id,
                    tokan:tokan_generate(32),
                    tokan_status:1,
                    browser:req.headers.host
                 }

             function tokan_generate(length) {
              var result           = '';
              var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
              var charactersLength = characters.length;
              for ( var i = 0; i < length; i++ ) {
                result += characters.charAt(Math.floor(Math.random() * charactersLength));              
             }
             return result;
          }
            
            Forget_password1.create(dataobj).exec(function (err,update) {
                user.totan=dataobj.tokan;

                /// Mailer.sendWelcomeMail(user);
               ///categoryName = data.name;
               return res.json(user)
             });  

       });


   
    },

    forget_password_link : function(req,res) {
        
        ///req.param('tokan');


       var exits =  Forget_password1.find({
            where: { tokan:req.param('tokan') , tokan_status: 1  },
            }).exec(function(err,data){
            if(data.length>0){
                 var obj={
                    status:'success',
                   
                    message:'Successfully ',
                    tokan:req.param('tokan'),
                }
                res.json({record:obj});
            }
            else{
                var obj={
                    status:'error',
                    message:' this tokan not exits',
                    tokan:req.param('tokan'),
                }
                res.json({record:obj});
            }

        });


    },
    update_password: async function(req,res){

    var tokan_exits = await  Forget_password1.find({ tokan:req.param('tokan'),tokan_status:1 });
        if(tokan_exits.length>0)
        {
               await Client.update({'id':tokan_exits.userid},{password:req.param('password') });
               await Forget_password1.update({'id':tokan_exits.id},{tokan_status:0 });
               var obj={
                   status:'success',
                   message:'user password Successfully updated'



                }
                res.json({record:obj});
        }
        else
        {
             var obj={
                   status:'error',
                   message:"This tokan already use  please sent again request "

                }
                res.json({record:obj});
        }

                


    }
  
};

