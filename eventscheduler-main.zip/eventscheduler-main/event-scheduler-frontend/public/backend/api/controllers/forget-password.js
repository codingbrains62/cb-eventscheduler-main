module.exports = {


  friendlyName: 'Forget password',


  description: '',


  inputs: {

    email:{
     type:'string',
     required:true,

    }

  },


 

  exits: {
     invalid: {
      statusCode: 409,
      description: ' email and password is required.'
    },
    redirect: {
      responseType: 'redirect'
    },
    somethingHappened: {
         responseType: 'serverError'
   }
  },
  fn: async function (inputs, exits) {

    var res=this.res;
    var req=this.req;

       Client.findOne({'emailAddress':inputs.email}).exec(function(err,user){
               if(err)  {
                    res.send(500, {'err' :err} );
                 }

                if(!user)
                {
                    var noacountuser= [{message:'this email address'+inputs.email+' Not found'}];
                   
                    //res.forbidden();
                    res.json(202,{error:noaountuser});
                    return ;
                }

                var dataobj={
                    userid:user.id,
                    tokan:tokan_generate(32),
                    tokan_status:1,
                    browser:req.headers.host
                 }

             function tokan_generate(length) {
              var result           = '';
              var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
              var charactersLength = characters.length;
              for ( var i = 0; i < length; i++ ) {
                result += characters.charAt(Math.floor(Math.random() * charactersLength));              
             }
             return result;
          }
            
            Forget_password1.create(dataobj).exec(function (err,update) {
                user.totan=dataobj.tokan;

                /// Mailer.sendWelcomeMail(user);
               ///categoryName = data.name;
               return res.json(user)
             });  

       });
  

      

  }


};
