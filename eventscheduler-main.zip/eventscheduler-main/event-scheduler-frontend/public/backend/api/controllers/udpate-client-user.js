module.exports = {


  friendlyName: 'Udpate client user',


  description: '',


  inputs: {

    

   
    email:{
       type: 'string',
      required: true,
      isEmail: true,
      maxLength: 200,
      example: 'mary.sue@example.com'
    },
     fullName:{
       type: 'string',
      required: true,
      
      maxLength: 200,
      example: 'Amit shaha'
    },
    altemail:{
       type: 'string',
      required: true,
      isEmail: true,
      maxLength: 200,
      example: 'mary.sue@example.com'
    },
    company:{
       type: 'string',
      required: true,
      
      maxLength: 200,
      example: 'codingbrain@gmail.com'
    },
    phone:{
      type: 'string',
      required: true,
      description:'user phone number',
      example:'9145784571'
      
    },
     cellphone:{
      type: 'string',
      required: true,
      description:'user  Cell  phone number',
      example:'9145784571'
      
    }
    ,
    security_Level:{
      type: 'string',
      required: true,
      description:'user  Security Level   ',
      example:'this is lappi'
      
    },

 billingaddressPart1:{
     type: 'string',
      required: true,
      description:'user  Security Level   ',
      example:'this is address 1 - 5 ',

 },
 company_name:{
      type: 'string',
      required: true,
      description:'organization name ',
      example:'this is lappi key '
 }
   

  },


  exits: {
    success:{
      status:200,
      message:'Record has been update successfully '
    },
    failed:{
      status:202,
      message:'Some thing error please try again'
    },
    error:{
      status:404,
      message:'Page Not found '
    }

  },


  fn: async function (inputs,exits) {
    var req=this.req;
    var res=this.res;

   

     try{
         /// console.log(inputs)

         data = {
            'fullName':inputs.fullName,
            'alternateEmailAddress':inputs.altemail,
            'phone':inputs.phone,
            'cellphone':inputs.cellphone,
            'SecurityLevel':inputs.security_Level,
            
            
          }

         
            await Client.update({id:1},  data);
             var data= {
                      description:'User profile update Successfully ',
                      actorId:1,
                      actorType:'Client',
                      actorDisplayName:inputs.fullName,
                      category:'Other'
                    }

                      
                    var dataobj = await  HistoricalEvent.create(data).exec(function(err,logs){
                       
                       if(err)
                       {
                          res.json({record:err});
                       }


                    });

                  var updatebyrequest=[];  
           clientdata= await Client.findOne({id:1});

           if(clientdata.emailAddress!=inputs.email)
           {
               var update={
                'current_record':clientdata.emailAddress,
                'new_record':inputs.email
               }
               updatebyrequest.push(update)
           }
           

           billingAccount= await BillingAccount.findOne({id:clientdata.billingAccount});

           if(billingAccount.addressPart1!=inputs.billingaddressPart1)
           {
               var update={
                'current_record':billingAccount.addressPart1,
                'new_record':inputs.billingaddressPart1
               }
               updatebyrequest.push(update)
           }
           

           org= await Org.findOne({id:billingAccount.org});
           if(org.name!=inputs.name)
           {
               var update={
                'current_record':org.name,
                'new_record':inputs.name
               }
               updatebyrequest.push(update)
           }

           success={
      status:200,
      message:'Record has been update successfully '
    }

           res.json({data:success})


             

     }catch(error){

      res.json({error:error})
     }

  }


};
