module.exports = {


  friendlyName: 'Forget password link',


  description: '',


  inputs: {



  },


  exits: {

  },


  fn: async function (inputs) {

   


     

    try{

       var req=this.req;
    var res= this.res;
      var data = await Forget_password1.findOne({ where: { tokan:req.param('tokan') , tokan_status: 1  }});

     

            if(data){
                 var obj={
                    status:'success',
                   
                    message:'Successfully ',
                    tokan:req.param('tokan'),
                }
                res.json({record:obj});
            }
            else{
                var obj={
                    status:'error',
                    message:' this tokan already used',
                    tokan:req.param('tokan'),
                }
                res.json({record:obj});
            }
    }
    catch(errors)
    {
           var obj={
                    status:errors,
                    status_code:500,
                    message:'Internal Server error ',
                   
                }
                res.json({record:obj});

    }


   

  }


};
