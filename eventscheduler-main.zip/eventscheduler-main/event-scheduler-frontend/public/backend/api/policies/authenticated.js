/**
 * Allow any authenticated user.
 */
module.exports = function (req, res, next) {

  // User is allowed, proceed to controller
  var is_auth = req.isAuthenticated();

  //res.send(req.session)
  if (is_auth) return next();
  // User is not allowed
  else return res.forbidden('You are not authenticated ');
};