-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2021 at 05:18 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clas_info_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `archive`
--

CREATE TABLE `archive` (
  `id` int(11) NOT NULL,
  `createdAt` bigint(20) DEFAULT NULL,
  `fromModel` varchar(255) DEFAULT NULL,
  `originalRecord` longtext DEFAULT NULL,
  `originalRecordId` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `billingaccount`
--

CREATE TABLE `billingaccount` (
  `id` int(11) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `isInternational` tinyint(1) DEFAULT NULL,
  `addressPart1` varchar(255) DEFAULT NULL,
  `addressPart2` varchar(255) DEFAULT NULL,
  `addressPart3` varchar(255) DEFAULT NULL,
  `addressPart4` varchar(255) DEFAULT NULL,
  `addressPart5` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `bookkeepingId` varchar(255) DEFAULT NULL,
  `feeSchedule` varchar(255) DEFAULT NULL,
  `isMonthlyBillingSummaryEnabled` tinyint(1) DEFAULT NULL,
  `isEBilling` tinyint(1) DEFAULT NULL,
  `hubspotaccountlink` varchar(255) DEFAULT NULL,
  `org` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `billingaccount`
--

INSERT INTO `billingaccount` (`id`, `createdAt`, `updatedAt`, `isInternational`, `addressPart1`, `addressPart2`, `addressPart3`, `addressPart4`, `addressPart5`, `phone`, `fax`, `bookkeepingId`, `feeSchedule`, `isMonthlyBillingSummaryEnabled`, `isEBilling`, `hubspotaccountlink`, `org`) VALUES
(1, '2021-07-06 14:06:24', '2021-07-06 14:06:24', NULL, 'ghfhdgsae', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(2, '2021-07-06 14:48:55', '2021-07-06 14:48:55', 0, '', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 7),
(3, '2021-07-06 14:55:22', '2021-07-06 14:55:22', 0, '', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 8),
(4, '2021-07-06 14:57:06', '2021-07-06 14:57:06', 0, '', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 9),
(5, '2021-07-06 14:58:21', '2021-07-06 14:58:21', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 10),
(6, '2021-07-06 15:16:11', '2021-07-06 15:16:11', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 15),
(7, '2021-07-06 17:39:45', '2021-07-06 17:39:45', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 6),
(8, '2021-07-08 10:50:46', '2021-07-08 10:50:46', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 7),
(9, '2021-07-08 10:52:41', '2021-07-08 10:52:41', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 8),
(10, '2021-07-08 10:52:46', '2021-07-08 10:52:46', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 9),
(11, '2021-07-08 10:55:25', '2021-07-08 10:55:25', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 10),
(12, '2021-07-08 10:55:51', '2021-07-08 10:55:51', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 11),
(13, '2021-07-08 10:56:23', '2021-07-08 10:56:23', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 12),
(14, '2021-07-08 10:57:54', '2021-07-08 10:57:54', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 13),
(15, '2021-07-08 10:58:22', '2021-07-08 10:58:22', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 14),
(16, '2021-07-08 10:59:50', '2021-07-08 10:59:50', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 15),
(17, '2021-07-08 11:00:35', '2021-07-08 11:00:35', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 16),
(18, '2021-07-08 11:02:36', '2021-07-08 11:02:36', 0, 'lucknow', '', '', '', '', '', '', '', 'Retail 1', 0, 0, '', 17);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `tosAcceptedByIp` varchar(255) DEFAULT NULL,
  `lastSeenAt` double DEFAULT NULL,
  `SecurityLevel` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `emailAddress` varchar(255) DEFAULT NULL,
  `alternateEmailAddress` varchar(255) DEFAULT NULL,
  `mandate` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `cellPhone` varchar(255) DEFAULT NULL,
  `isOnHold` tinyint(1) DEFAULT NULL,
  `isDisabled` tinyint(1) DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT NULL,
  `bookkeepingId` varchar(255) DEFAULT NULL,
  `perInvoiceMax` double DEFAULT NULL,
  `ebilling` tinyint(1) DEFAULT NULL,
  `alwayschargecc` tinyint(1) DEFAULT NULL,
  `isonhubspot` tinyint(1) DEFAULT NULL,
  `HubspotClientLink` varchar(255) DEFAULT NULL,
  `createdBy` double DEFAULT NULL,
  `billingAccount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `createdAt`, `updatedAt`, `username`, `password`, `tosAcceptedByIp`, `lastSeenAt`, `SecurityLevel`, `fullName`, `emailAddress`, `alternateEmailAddress`, `mandate`, `phone`, `cellPhone`, `isOnHold`, `isDisabled`, `isDeleted`, `bookkeepingId`, `perInvoiceMax`, `ebilling`, `alwayschargecc`, `isonhubspot`, `HubspotClientLink`, `createdBy`, `billingAccount`) VALUES
(1, '2021-07-06 14:04:42', '2021-07-08 15:16:48', 'Amit sharma', '$2a$10$QQKd58p1W5XDMVP8Y0AjmOeCkBc9qW4Jykch/lrkiFEFYOASaC5MO', NULL, NULL, 'user', 'iuser', 'amitsharma@gmail.com', 'amitsharma@gmail.com', NULL, '745464545464', NULL, 1, 1, 1, NULL, 1, 1, 1, 1, 'gfgh', 1, 1),
(2, '2021-07-06 14:57:06', '2021-07-08 10:50:17', 'amitsharma@mail.com', '$2a$10$QQKd58p1W5XDMVP8Y0AjmOeCkBc9qW4Jykch/lrkiFEFYOASaC5MO', '', 1625741417165, 'user', 'hello', 'amitverma@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 4),
(3, '2021-07-06 14:58:21', '2021-07-08 10:50:05', 'amitsharma@mail.com', '$2a$10$QQKd58p1W5XDMVP8Y0AjmOeCkBc9qW4Jykch/lrkiFEFYOASaC5MO', '', 0, 'user', 'hello', 'amit@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 5),
(4, '2021-07-06 15:16:11', '2021-07-08 10:50:05', 'amitsharma@mail.com', '$2a$10$QQKd58p1W5XDMVP8Y0AjmOeCkBc9qW4Jykch/lrkiFEFYOASaC5MO', '', 0, 'user', 'hello', 'amit@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 6),
(5, '2021-07-06 17:39:45', '2021-07-08 10:50:05', 'amitsharma@mail.com', '$2a$10$QQKd58p1W5XDMVP8Y0AjmOeCkBc9qW4Jykch/lrkiFEFYOASaC5MO', '', 0, 'user', 'hello', 'amit@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 7),
(6, '2021-07-08 10:50:47', '2021-07-08 10:50:47', 'amitsharma@mail.com', '$2a$10$i4aU1Lfk8e3iKNp3pkSck.q5CrnR9UGVsVxjtvsXFyS4GgE/K/c8e', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 8),
(7, '2021-07-08 10:52:41', '2021-07-08 10:52:41', 'amitsharma@mail.com', '$2a$10$0xWqQfdnGDL9Jepxi4ZeiOJHkIuCKC4yyxkENW3f/Pe0DH.XjUCze', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 9),
(8, '2021-07-08 10:52:46', '2021-07-08 10:52:46', 'amitsharma@mail.com', '$2a$10$xF6GzIHvUWtJYo/EJ6IUN.TgYfeJY8bc8tEVQlX/C.WkBG3PAgIwG', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 10),
(9, '2021-07-08 10:55:25', '2021-07-08 10:55:25', 'amitsharma@mail.com', '$2a$10$zyN59TlFiPNxXBuUulRTL..EDWw7qUVCLIa7j9LbIURTF9bHM4EGa', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 11),
(10, '2021-07-08 10:55:51', '2021-07-08 10:55:51', 'amitsharretetma@mail.com', '$2a$10$q9xUkNoQSy5XOuEJJZwBAu7R.c3p9CpAAim6GK20ipF7GF/ime7Tq', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 12),
(11, '2021-07-08 10:56:23', '2021-07-08 10:56:23', 'amitsharretetma@mail.com', '$2a$10$fhJPQyaYjZDXv.r/gVgWfefNiIB59kr8mbEqblceFiefSbSXH3Jw.', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 13),
(12, '2021-07-08 10:57:54', '2021-07-08 10:57:54', 'amitsharretetma@mail.com', '$2a$10$gCm1vhYCGB83gk.NecebK.dvP14Vade4bYmGbuEw2bchEdBFELuxG', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 14),
(13, '2021-07-08 10:58:22', '2021-07-08 10:58:22', 'amitsharretetma@mail.com', '$2a$10$.9fT9Gb9l9FztKnKVo4j7ek/XOhKTGoOmw/Va1wJHflUsg5RDhf9G', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 15),
(14, '2021-07-08 10:59:50', '2021-07-08 10:59:50', 'amitsharretetma@mail.com', '$2a$10$LyPPVAGvGUfYJiYfohl1zuusR8fJ5sS/yCdEA4GaDr3FVchwVkld2', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 16),
(15, '2021-07-08 11:00:35', '2021-07-08 11:00:35', 'amitsharretetma@mail.com', '$2a$10$c9EsS..jaL/d.bFY/O5IbuhvcF7uOnPKu6sHec9/QvJd2We.HMKzO', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 17),
(16, '2021-07-08 11:02:36', '2021-07-08 11:02:36', 'amitsharretetma@mail.com', '$2a$10$YM0AJ.vuBxkUHCH/kPBRNe1Fv1/6ceznGOhncxXKbR/k0T9i8wu8q', '', 0, 'user', 'hello', 'amidsft@gmail.com', 'amitsharmadv@gmail.com', 'Corporate', '9140690735', '', 0, 0, 0, '', 0, 0, 0, 0, '', 1, 18);

-- --------------------------------------------------------

--
-- Table structure for table `emailevent`
--

CREATE TABLE `emailevent` (
  `id` int(11) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `actorUserId` double DEFAULT NULL,
  `actorDisplayName` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `client` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `errorevent`
--

CREATE TABLE `errorevent` (
  `id` int(11) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `actorUserId` double DEFAULT NULL,
  `actorDisplayName` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `client` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `forget_password`
--

CREATE TABLE `forget_password` (
  `id` int(11) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `tokan` varchar(255) DEFAULT NULL,
  `userid` double DEFAULT NULL,
  `tokan_status` tinyint(1) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `forget_password`
--

INSERT INTO `forget_password` (`id`, `createdAt`, `updatedAt`, `tokan`, `userid`, `tokan_status`, `browser`) VALUES
(1, '2021-07-08 12:01:19', '2021-07-08 12:01:19', 'yI0JTWXg4Bcf0sexPVGe9YPqjVo5s9PO', 1, 1, 'localhost:1337'),
(2, '2021-07-08 12:14:02', '2021-07-08 12:14:02', 'p6KTBPBK4cdGJAY2IJXt9ugcwGdlhqXw', 1, 0, 'localhost:1337');

-- --------------------------------------------------------

--
-- Table structure for table `historicalevent`
--

CREATE TABLE `historicalevent` (
  `id` int(11) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `actorId` double DEFAULT NULL,
  `actorType` varchar(255) DEFAULT NULL,
  `actorDisplayName` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `historicalevent`
--

INSERT INTO `historicalevent` (`id`, `createdAt`, `updatedAt`, `description`, `actorId`, `actorType`, `actorDisplayName`, `category`) VALUES
(1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'login', 0, 'Client', 'Neha kumari sharma', 'Login'),
(2, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'login', 0, 'Client', 'Neha kumari sharma', 'Login'),
(3, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'login', 1, 'Client', 'Neha kumari sharma', 'Login'),
(4, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'login', 1, 'Client', 'Neha kumari sharma', 'Login'),
(5, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'login', 1, 'Client', 'Neha kumari sharma', 'Login'),
(6, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'login', 1, 'Client', 'Neha kumari sharma', 'Login'),
(7, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'login', 1, 'Client', 'Neha kumari sharma', 'Login'),
(8, '2021-07-02 04:57:01', '2021-07-02 04:57:01', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(9, '2021-07-02 07:13:12', '2021-07-02 07:13:12', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(10, '2021-07-02 07:27:22', '2021-07-02 07:27:22', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(11, '2021-07-02 07:27:29', '2021-07-02 07:27:29', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(12, '2021-07-02 08:19:31', '2021-07-02 08:19:31', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(13, '2021-07-02 08:19:34', '2021-07-02 08:19:34', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(14, '2021-07-02 08:19:37', '2021-07-02 08:19:37', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(15, '2021-07-02 08:19:39', '2021-07-02 08:19:39', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(16, '2021-07-02 08:19:41', '2021-07-02 08:19:41', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(17, '2021-07-02 08:19:43', '2021-07-02 08:19:43', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(18, '2021-07-02 08:19:46', '2021-07-02 08:19:46', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(19, '2021-07-02 08:19:47', '2021-07-02 08:19:47', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(20, '2021-07-02 08:19:48', '2021-07-02 08:19:48', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(21, '2021-07-02 08:19:50', '2021-07-02 08:19:50', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(22, '2021-07-02 08:19:52', '2021-07-02 08:19:52', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(23, '2021-07-02 08:37:04', '2021-07-02 08:37:04', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(24, '2021-07-02 08:44:53', '2021-07-02 08:44:53', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(25, '2021-07-02 08:55:09', '2021-07-02 08:55:09', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(26, '2021-07-02 09:53:59', '2021-07-02 09:53:59', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(27, '2021-07-02 09:57:10', '2021-07-02 09:57:10', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(28, '2021-07-02 09:57:19', '2021-07-02 09:57:19', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(29, '2021-07-02 09:57:20', '2021-07-02 09:57:20', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(30, '2021-07-02 10:08:56', '2021-07-02 10:08:56', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(31, '2021-07-02 10:09:08', '2021-07-02 10:09:08', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(32, '2021-07-02 10:10:27', '2021-07-02 10:10:27', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(33, '2021-07-04 23:13:25', '2021-07-04 23:13:25', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(34, '2021-07-04 23:16:54', '2021-07-04 23:16:54', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(35, '2021-07-04 23:17:57', '2021-07-04 23:17:57', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(36, '2021-07-04 23:21:47', '2021-07-04 23:21:47', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(37, '2021-07-05 02:48:39', '2021-07-05 02:48:39', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(38, '2021-07-05 02:52:50', '2021-07-05 02:52:50', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(39, '2021-07-05 02:53:41', '2021-07-05 02:53:41', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(40, '2021-07-05 02:58:35', '2021-07-05 02:58:35', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(41, '2021-07-05 03:02:58', '2021-07-05 03:02:58', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(42, '2021-07-05 03:03:38', '2021-07-05 03:03:38', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(43, '2021-07-05 03:05:48', '2021-07-05 03:05:48', 'login', 1, 'Client', 'Amit Kumar  sharma', 'Login'),
(44, '2021-07-06 06:20:28', '2021-07-06 06:20:28', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(45, '2021-07-06 12:08:34', '2021-07-06 12:08:34', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(46, '2021-07-06 12:12:00', '2021-07-06 12:12:00', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(47, '2021-07-06 12:13:15', '2021-07-06 12:13:15', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(48, '2021-07-06 12:14:19', '2021-07-06 12:14:19', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(49, '2021-07-06 12:14:31', '2021-07-06 12:14:31', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(50, '2021-07-06 12:16:20', '2021-07-06 12:16:20', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(51, '2021-07-06 12:16:33', '2021-07-06 12:16:33', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(52, '2021-07-06 12:22:04', '2021-07-06 12:22:04', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(53, '2021-07-06 12:22:18', '2021-07-06 12:22:18', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(54, '2021-07-06 12:22:22', '2021-07-06 12:22:22', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(55, '2021-07-06 12:24:40', '2021-07-06 12:24:40', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(56, '2021-07-06 12:24:47', '2021-07-06 12:24:47', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(57, '2021-07-06 12:24:55', '2021-07-06 12:24:55', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(58, '2021-07-06 12:26:55', '2021-07-06 12:26:55', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(59, '2021-07-06 12:27:07', '2021-07-06 12:27:07', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(60, '2021-07-06 12:32:55', '2021-07-06 12:32:55', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(61, '2021-07-06 12:33:04', '2021-07-06 12:33:04', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(62, '2021-07-06 12:33:13', '2021-07-06 12:33:13', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(63, '2021-07-06 12:36:40', '2021-07-06 12:36:40', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(64, '2021-07-06 12:43:40', '2021-07-06 12:43:40', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(65, '2021-07-06 12:45:22', '2021-07-06 12:45:22', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(66, '2021-07-06 12:47:16', '2021-07-06 12:47:16', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(67, '2021-07-06 14:57:07', '2021-07-06 14:57:07', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(68, '2021-07-06 14:58:21', '2021-07-06 14:58:21', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(69, '2021-07-06 15:16:12', '2021-07-06 15:16:12', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(70, '2021-07-06 17:39:46', '2021-07-06 17:39:46', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(71, '2021-07-06 18:40:38', '2021-07-06 18:40:38', 'login', 2, 'Client', 'hello', 'Login'),
(72, '2021-07-06 18:49:54', '2021-07-06 18:49:54', 'login', 2, 'Client', 'hello', 'Login'),
(73, '2021-07-06 18:51:33', '2021-07-06 18:51:33', 'login', 2, 'Client', 'hello', 'Login'),
(74, '2021-07-06 18:51:36', '2021-07-06 18:51:36', 'login', 2, 'Client', 'hello', 'Login'),
(75, '2021-07-06 18:53:56', '2021-07-06 18:53:56', 'login', 2, 'Client', 'hello', 'Login'),
(76, '2021-07-06 18:54:54', '2021-07-06 18:54:54', 'login', 2, 'Client', 'hello', 'Login'),
(77, '2021-07-06 18:56:06', '2021-07-06 18:56:06', 'login', 2, 'Client', 'hello', 'Login'),
(78, '2021-07-06 18:58:40', '2021-07-06 18:58:40', 'login', 2, 'Client', 'hello', 'Login'),
(79, '2021-07-06 19:00:24', '2021-07-06 19:00:24', 'login', 2, 'Client', 'hello', 'Login'),
(80, '2021-07-06 19:14:51', '2021-07-06 19:14:51', 'login', 2, 'Client', 'hello', 'Login'),
(81, '2021-07-06 19:15:52', '2021-07-06 19:15:52', 'login', 2, 'Client', 'hello', 'Login'),
(82, '2021-07-06 19:15:56', '2021-07-06 19:15:56', 'login', 2, 'Client', 'hello', 'Login'),
(83, '2021-07-06 19:15:58', '2021-07-06 19:15:58', 'login', 2, 'Client', 'hello', 'Login'),
(84, '2021-07-06 19:16:00', '2021-07-06 19:16:00', 'login', 2, 'Client', 'hello', 'Login'),
(85, '2021-07-06 19:16:42', '2021-07-06 19:16:42', 'login', 2, 'Client', 'hello', 'Login'),
(86, '2021-07-06 19:18:31', '2021-07-06 19:18:31', 'login', 2, 'Client', 'hello', 'Login'),
(87, '2021-07-06 19:18:36', '2021-07-06 19:18:36', 'login', 2, 'Client', 'hello', 'Login'),
(88, '2021-07-06 19:38:09', '2021-07-06 19:38:09', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(89, '2021-07-06 19:40:19', '2021-07-06 19:40:19', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(90, '2021-07-06 19:40:50', '2021-07-06 19:40:50', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(91, '2021-07-06 19:42:14', '2021-07-06 19:42:14', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(92, '2021-07-07 10:17:55', '2021-07-07 10:17:55', 'login', 0, 'Client', 'hello', 'Login'),
(93, '2021-07-07 10:19:14', '2021-07-07 10:19:14', 'login', 0, 'Client', 'hello', 'Login'),
(94, '2021-07-07 10:22:15', '2021-07-07 10:22:15', 'login', 2, 'Client', 'hello', 'Login'),
(95, '2021-07-07 10:30:50', '2021-07-07 10:30:50', 'login', 2, 'Client', 'hello', 'Login'),
(96, '2021-07-08 10:37:16', '2021-07-08 10:37:16', 'login', 2, 'Client', 'hello', 'Login'),
(97, '2021-07-08 10:40:40', '2021-07-08 10:40:40', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(98, '2021-07-08 10:40:40', '2021-07-08 10:40:40', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(99, '2021-07-08 10:40:45', '2021-07-08 10:40:45', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(100, '2021-07-08 10:40:48', '2021-07-08 10:40:48', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(101, '2021-07-08 10:48:45', '2021-07-08 10:48:45', 'reset  password  not Successfully ', 1, 'Client', 'username', 'Login'),
(102, '2021-07-08 10:50:06', '2021-07-08 10:50:06', 'reset password Successfully ', 1, 'Client', 'username', 'Login'),
(103, '2021-07-08 10:50:17', '2021-07-08 10:50:17', 'login', 2, 'Client', 'hello', 'Login'),
(104, '2021-07-08 10:50:47', '2021-07-08 10:50:47', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(105, '2021-07-08 10:52:42', '2021-07-08 10:52:42', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(106, '2021-07-08 10:52:46', '2021-07-08 10:52:46', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(107, '2021-07-08 10:55:26', '2021-07-08 10:55:26', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(108, '2021-07-08 10:55:52', '2021-07-08 10:55:52', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(109, '2021-07-08 10:56:24', '2021-07-08 10:56:24', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(110, '2021-07-08 10:58:23', '2021-07-08 10:58:23', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(111, '2021-07-08 10:59:51', '2021-07-08 10:59:51', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(112, '2021-07-08 11:00:35', '2021-07-08 11:00:35', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(113, '2021-07-08 11:02:36', '2021-07-08 11:02:36', 'Add user insert Successfully ', 1, 'Client', 'hello', 'Other'),
(114, '2021-07-08 11:03:14', '2021-07-08 11:03:14', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(115, '2021-07-08 15:15:45', '2021-07-08 15:15:45', 'reset  password  not Successfully ', 1, 'Client', 'username', 'Login'),
(116, '2021-07-08 15:16:41', '2021-07-08 15:16:41', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other'),
(117, '2021-07-08 15:16:48', '2021-07-08 15:16:48', 'User profile update Successfully ', 1, 'Client', 'iuser', 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `note`
--

CREATE TABLE `note` (
  `id` int(11) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `authorDisplayName` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `isBusinessComment` tinyint(1) DEFAULT NULL,
  `audience` varchar(255) DEFAULT NULL,
  `createdBy` double DEFAULT NULL,
  `client` int(11) DEFAULT NULL,
  `billingaccount` int(11) DEFAULT NULL,
  `org` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `org`
--

CREATE TABLE `org` (
  `id` int(11) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `org`
--

INSERT INTO `org` (`id`, `createdAt`, `updatedAt`, `name`, `category`) VALUES
(1, '2021-07-06 17:32:22', '2021-07-06 17:32:22', 'cbhgfhgdhgfj', 'ABL/Factor'),
(2, '2021-07-06 17:33:50', '2021-07-06 17:33:50', 'cbhgfhgdhgfj', 'ABL/Factor'),
(3, '2021-07-06 17:34:00', '2021-07-06 17:34:00', 'cbhgfhgdhgfj', 'ABL/Factor'),
(4, '2021-07-06 17:36:42', '2021-07-06 17:36:42', 'cbhgfhgdhgfj', 'ABL/Factor'),
(5, '2021-07-06 17:38:03', '2021-07-06 17:38:03', 'cbhgfhgdhgfj', 'ABL/Factor'),
(6, '2021-07-06 17:39:45', '2021-07-06 17:39:45', 'cbhgfhgdhgfj', 'ABL/Factor'),
(7, '2021-07-08 10:50:46', '2021-07-08 10:50:46', 'cbhgfhgdhgfj', 'ABL/Factor'),
(8, '2021-07-08 10:52:41', '2021-07-08 10:52:41', 'cbhgfhgdhgfj', 'ABL/Factor'),
(9, '2021-07-08 10:52:46', '2021-07-08 10:52:46', 'cbhgfhgdhgfj', 'ABL/Factor'),
(10, '2021-07-08 10:55:25', '2021-07-08 10:55:25', 'cbhgfhgdhgfj', 'ABL/Factor'),
(11, '2021-07-08 10:55:51', '2021-07-08 10:55:51', 'cbhgfhgdhgfj', 'ABL/Factor'),
(12, '2021-07-08 10:56:23', '2021-07-08 10:56:23', 'cbhgfhgdhgfj', 'ABL/Factor'),
(13, '2021-07-08 10:57:54', '2021-07-08 10:57:54', 'cbhgfhgdhgfj', 'ABL/Factor'),
(14, '2021-07-08 10:58:22', '2021-07-08 10:58:22', 'cbhgfhgdhgfj', 'ABL/Factor'),
(15, '2021-07-08 10:59:50', '2021-07-08 10:59:50', 'cbhgfhgdhgfj', 'ABL/Factor'),
(16, '2021-07-08 11:00:35', '2021-07-08 11:00:35', 'cbhgfhgdhgfj', 'ABL/Factor'),
(17, '2021-07-08 11:02:35', '2021-07-08 11:02:35', 'cbhgfhgdhgfj', 'ABL/Factor');

-- --------------------------------------------------------

--
-- Table structure for table `uploadedfile`
--

CREATE TABLE `uploadedfile` (
  `id` int(11) NOT NULL,
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  `fd` varchar(255) DEFAULT NULL,
  `mimeType` varchar(255) DEFAULT NULL,
  `bucket` varchar(255) DEFAULT NULL,
  `region` varchar(255) DEFAULT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `downloadName` varchar(255) DEFAULT NULL,
  `wasAutoGenerated` tinyint(1) DEFAULT NULL,
  `isAlias` tinyint(1) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `attachedToClient` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `archive`
--
ALTER TABLE `archive`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `billingaccount`
--
ALTER TABLE `billingaccount`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `emailevent`
--
ALTER TABLE `emailevent`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `errorevent`
--
ALTER TABLE `errorevent`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `forget_password`
--
ALTER TABLE `forget_password`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `historicalevent`
--
ALTER TABLE `historicalevent`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `note`
--
ALTER TABLE `note`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `org`
--
ALTER TABLE `org`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `uploadedfile`
--
ALTER TABLE `uploadedfile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `archive`
--
ALTER TABLE `archive`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `billingaccount`
--
ALTER TABLE `billingaccount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `emailevent`
--
ALTER TABLE `emailevent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `errorevent`
--
ALTER TABLE `errorevent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `forget_password`
--
ALTER TABLE `forget_password`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `historicalevent`
--
ALTER TABLE `historicalevent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `note`
--
ALTER TABLE `note`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `org`
--
ALTER TABLE `org`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `uploadedfile`
--
ALTER TABLE `uploadedfile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
