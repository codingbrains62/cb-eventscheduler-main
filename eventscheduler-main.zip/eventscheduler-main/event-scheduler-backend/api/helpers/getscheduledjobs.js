
module.exports = {


  friendlyName: 'When the server starts',


  description: '',


  inputs: {
    which:{
      type:'string',
      description:'running, not running, and all'
    }

  },


  exits: {

  },


  fn: async function (inputs) {

      var res= this.res;
      var req= this.req

      try{

        if(inputs.which === 'Running'){
            var events_arr = await Event.find({select: ['*']}).where({'event_status':1, 'currently_running':1,next_run:{ '!=':'Expired'}}).sort([{id:'DESC'}]);
        }else if(inputs.which === 'Not Running'){
            var events_arr = await Event.find({select: ['*']}).where({'event_status':1, 'currently_running':0,next_run:{ '!=':'Expired'}}).sort([{id:'DESC'}]);
        }else if(inputs.which === 'All'){
            var events_arr = await Event.find({select: ['*']}).sort([{id:'DESC'}]); 
        }else{
            var events_arr = await Event.find({select: ['*']}).where({'event_status':0,'currently_running':0,next_run:{ '!=':'Expired'}}).sort([{id:'DESC'}]); 
        }
        
        
        
        var arrJobs = [];

        if(events_arr.length!==0){

          events_arr.map(data=>{
              
              if(data.frequency_type==='one_at_time'){
                     var interval = 'Once';
                     var id = data.id;
                     var duration = data.duration.split("&"); 
                     var frequency = data.frequency.split(":"); 
                     var startDate= duration[0];
                     startDate=startDate.split('-');
                    
                     const rule = new sails.config.globals.schedule.RecurrenceRule();
                     rule.hour = frequency[0];
                     rule.minute = frequency[1];
                     rule.second = frequency[2];
                     rule.date = parseInt(startDate[2]);
                     rule.month = parseInt(((startDate[1].substr(1, 1))-1));
                     rule.year  = parseInt(startDate[0]);
                     
                     arrJobs.push(rule);
              }
              else if(data.frequency_type==='recurring'){

                    var interval=data.frequency.split('&')[0];

                    if(interval==='Daily'){
                      
                      var id = data.id;
                      var duration = data.duration.split("&"); 
                      var frequency = data.frequency.split("&");
                      var frequency_time= frequency[1].split(':');

                      const rule = new sails.config.globals.schedule.RecurrenceRule();
                      rule.dayOfWeek = [0, 1, 2, 3, 4, 5, 6];
                      rule.hour = frequency_time[0];
                      rule.minute = frequency_time[1];
                      rule.second = frequency_time[2];

                      arrJobs.push(rule);

                    }else if(interval==='Weekly'){
                      
                        var id = data.id;
                        var duration = data.duration.split("&"); 
                        var frequency = data.frequency.split("&");
                        var frequency_time= frequency[1].split(':');
  
                        const rule = new sails.config.globals.schedule.RecurrenceRule();
                        rule.dayOfWeek = [0];
                        rule.hour = frequency_time[0];
                        rule.minute = frequency_time[1];
                        rule.second = frequency_time[2];
  
                        arrJobs.push(rule);
                    }else if(interval==='Monthly'){
                      

                        var id = data.id;
                        var duration = data.duration.split("&"); 
                        var frequency = data.frequency.split("&");
                        var frequency_time= frequency[1].split(':');
  
                        const rule = new sails.config.globals.schedule.RecurrenceRule();
                        rule.month = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
                        rule.date = 1;
                        rule.hour = frequency_time[0];
                        rule.minute = frequency_time[1];
                        rule.second = frequency_time[2];

                        arrJobs.push(rule);
                    }
              }else if(data.frequency_type==='daily_every'){

                        var id = data.id;
                        var duration = data.duration.split("&"); 
                        var frequency = data.frequency.split("&");
                        var frequency_time= frequency[1].split(':');
                  
                        const rule = new sails.config.globals.schedule.RecurrenceRule();
                          rule.hour = parseInt(frequency[0]);
                          rule.minute = parseInt(frequency[1]);
                          rule.second = parseInt(frequency[2]);
                          var rulecopy =  new sails.config.globals.schedule.RecurrenceRule();

                          if(rule.hour != 0)
                            rulecopy.hour = rule.hour

                          if(rule.minute != 0)
                            rulecopy.minute = rule.minute

                          if(rule.second != 0)
                            rulecopy.second = rule.second

                          arrJobs.push(rulecopy);  
              }
              data.jobobj = arrJobs[arrJobs.length-1];               
          });          
        }
        return events_arr;
      }catch(error){
         console.log(error);
      }
   
  }


};
