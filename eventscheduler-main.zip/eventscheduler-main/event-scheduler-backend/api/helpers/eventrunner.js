module.exports = {


  friendlyName: 'Event Runner',


  description: '',


  inputs: {
    objEvent:{
      type:'ref',
      description: 'event obj '
    }
  },


  exits: {

  },


  fn: async function (inputs) {

      var res= this.res;
      var req= this.req
      bcrypt = require('bcrypt');
      const https = require('http');
      var fs = require("fs");

      async function getdata(url) {
        return new Promise((resolve, reject) => {
          https.get(url, (res) => {
            res.setEncoding('utf8');
            let data = '';
            res.on('data', (chunk) => {
              data = data + chunk;
            });
            res.on('end', () => {
              resolve(data);
            })
          }).on('error', (e) => {
            reject(e);
          });
        });
      }

      async function FileCreateAndWrite(url,filename){
        var files           = '';
        var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for ( var i = 0; i < 10; i++ ) {
          files += characters.charAt(Math.floor(Math.random() * charactersLength));
        }  
        var  data = await getdata(url);
        var createStream = fs.createWriteStream('eventApi/'+files+'.'+filename+".txt");
        createStream.end();
        var writeStream = fs.createWriteStream('eventApi/'+files+'.'+filename+".txt");
        writeStream.write(data);
        writeStream.end();
      }


      try{

        
        if(inputs.objEvent.file === ''){
          getdata(inputs.objEvent.url);
        }else{
          FileCreateAndWrite(inputs.objEvent.url,inputs.objEvent.file);
        }
        
       
        var datasave= {
          description:inputs.objEvent.event_name+' Event Ran Successfully ',
          actorId:0,
          actorDisplayName:'EventRunner',
          category:'System'
        }
        var save =  await Historylog.create(datasave);



        }catch(error){
            console.log(error);

                var data= {
                  description:error.details,
                  actorUserId:0,                  
                  actorDisplayName:"EventRunner",
                  category:'System'
            }
            await Errorlog.create(data);
        }
  }


};
