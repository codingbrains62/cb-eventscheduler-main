module.exports = {


  friendlyName: 'Event Job Scheduler',


  description: '',


  inputs: {
    objEvent:{
        type:'ref',
        description: 'event obj '
    }
  },


  exits: {

  },


  fn: async function (inputs) {

      var res= this.res;
      var req= this.req

      async  function RunEvent(oEvent)
      {
        await sails.helpers.eventrunner(oEvent);
        console.log('sails.helpers.eventrunner');       
      }

      try{

        console.log('EventJobScheduler Start');
        const job = sails.config.globals.schedule.scheduleJob(inputs.objEvent.event_name, inputs.objEvent.jobobj,function(){        
            RunEvent(inputs.objEvent);
        });

        

        }catch(error){
            console.log(error);

                var data= {
                  description:error.details,
                  actorUserId:0,                  
                  actorDisplayName:"EventJobScheduler",
                  category:'System'
            }
            await Errorlog.create(data);
        }
  }


};
