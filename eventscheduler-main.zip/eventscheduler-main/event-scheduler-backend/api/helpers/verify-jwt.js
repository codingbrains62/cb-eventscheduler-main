var jwt = require('jsonwebtoken')

module.exports = {
  friendlyName: 'Verify JWT',
  description: 'Verify a JWT token.',
  inputs: {
    req: {
      type: 'ref',
      friendlyName: 'Request',
      description: 'A reference to the request object (req).',
      required: true
    },
    res: {
      type: 'ref',
      friendlyName: 'Response',
      description: 'A reference to the response object (res).',
      required: false
    },
     subject: {
    type: "string",
   // required: true
    }
  },
  exits: {
    invalid: {

        description: 'Invalid token or no authentication present.',

    }
  },
  fn: async function (inputs, exits) {
    var req = inputs.req
    var res = inputs.res

     const payload = {
         sub: inputs.subject, // subject
         iss: "LogRocket Sails API" // issuer
        };


      var token = req.cookies.jwt 
     

       
    if (token) {


      
      var user = await User.findOne({token:token})

      if (!user) return exits.invalid() 
        // if it got this far, everything checks out, success
        req.user = user
        return exits.success(user)
         /* res.json({
            data:req.headers ,
            token:user
          })*/


     
    }
    return exits.invalid()
  }
}