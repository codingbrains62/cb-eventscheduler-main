module.exports = {


  friendlyName: 'View user',


  description: 'Display "User" page.',


  exits: {

    success:{
      description:"success",
    },
    error:{
      description:'error'
    }
    ,
    

  },


  fn: async function (inputs,exits) {

       var res= this.res;
       var req=this.req;

       try{


    
      users = await User.find({select: ['id','fullName','username','isDisabled']}).sort([{id:'DESC'}]);
       
        if(users.length===0)
        {
           return exits.error({
                    status: "error",
                    status_code:202,
                    message:"Something wont wrong ",
              });
        }
        else
        {
          var  new_arr=[];
          for (var k = 0; k < users.length; k++) {
                        var newarray='';
                         if(users[k].isDisabled == true)
                        {
                           
                               newarray={
                                "id":users[k].id,                        
                                "fullName":users[k].fullName+' - '+users[k].username,
                                 "isDisabled":'Active', 
                                }
                            new_arr.push(newarray);
                           
                        }
                        else  if(users[k].isDisabled == false){
                             newarray={
                                "id":users[k].id,                        
                                "fullName":users[k].fullName+' - '+users[k].username,
                                "isDisabled":"Deactive",                 
                                }
                                 new_arr.push(newarray);
                          }
          }
           return exits.success({
                    status: "success",
                    status_code:200,
                    message:new_arr,
              });
        }
       }
       catch(error){

        return res.json({record:{
                    status: "error",
                    status_code:500,
                    message:"Internal serverError ",
              }});
        
       }

  }


};
