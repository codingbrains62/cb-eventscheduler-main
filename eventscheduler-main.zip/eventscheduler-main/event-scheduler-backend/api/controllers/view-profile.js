module.exports = {


  friendlyName: 'View profile',


  description: 'Display "Profile" page.',


  inputs: {
    id:{
     type:'number',
     description:'User id'
    }
  },

  exits: {

    success: {
      //viewTemplatePath: 'pages/profile'
    }

  },


  fn: async function (inputs,exits) {

      var req=this.req;
      var res=this.res;

   try{

        var  users   = await  User.findOne({id:inputs.id});
        

              res.json({record:{
              status:"success",
              status_code:200,
              message:users
            }});      
   }
    catch(error){
      res.json({record:{
        status:"error",
        status_code:500,
        message:"Internal Server Error"
      }});

    }
  }


};
