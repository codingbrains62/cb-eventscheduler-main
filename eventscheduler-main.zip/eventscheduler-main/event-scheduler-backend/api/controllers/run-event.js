module.exports = {


  friendlyName: 'Run event',


  description: '',


  inputs: {
    id:{
      type:'number',
      description:'Remove user id'
    }
  },


  exits: {

  },


  fn: async function (inputs,exits) {

       var res= this.res;
       var req= this.req;

       try{
        

        var arryTemp = await sails.helpers.getscheduledjobs('All');
        var joblist = sails.config.globals.schedule.scheduledJobs;
        for (let index = 0; index < arryTemp.length; index++) {
          const element = arryTemp[index];          
          if(inputs.id === element.id){
            await sails.helpers.eventrunner(element);
          }              
        }


        return res.json({record:{
            status:"success",
            status_code:200,message:'Event Ran successfully',
        }});


       }
       catch(error){
          return res.json({record:{
                  status_code:500,
                  status:'error',
                  message:'Internal Server Error  '
                }});
       }

  }

};
