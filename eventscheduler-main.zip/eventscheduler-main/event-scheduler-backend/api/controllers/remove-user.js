module.exports = {


  friendlyName: 'Remove user',


  description: '',


  inputs: {
    id:{
      type:'number',
      description:'Remove user id'
    }

  },


  exits: {

  },


  fn: async function (inputs,exits) {

       var res= this.res;
       var req= this.req;

       try{
        var removed = await User.destroyOne({id: inputs.id});
        if (removed) {
              return res.json({record:{
                  status_code:200,
                  status:'success',
                  message:'User successfully removed'
                }});
          
        } else {
           
             return res.json({record:{
                  status_code:202,
                  status:'error',
                  message:'Something error '
                }});
        }


       }
       catch(error){
          return res.json({record:{
                  status_code:500,
                  status:'error',
                  message:'Internal Server Error  '
                }});
       }
  
  }


};
