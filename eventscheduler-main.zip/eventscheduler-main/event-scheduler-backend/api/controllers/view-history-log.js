module.exports = {


  friendlyName: 'View history log',


  description: 'Display "History log" page.',


  exits: {

    success: {
     description:"success",
    },
     error:{
      description:'error'
    }

  },


  fn: async function (inputs,exits) {

     var req= this.req;
     var res= this.res;

    try
    {
      historylog = await Historylog.find({}).sort([{id:'DESC'}]);
      if(historylog.length===0){
        return exits.error({
                    status: "error",
                    status_code:202,
                    message:"Something wont wrong ",
              });
      }
      else
      {
         return exits.success({
                    status: "success",
                    status_code:200,
                    message:historylog,
              });

      }
    }
    catch(error){

              return res.json({record:{
                    status: "error",
                    status_code:500,
                    message:"Internal serverError ",
              }})
    } 


  }


};
