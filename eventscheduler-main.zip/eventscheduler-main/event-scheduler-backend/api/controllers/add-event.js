bcrypt = require('bcrypt');
const https = require('http');
var fs = require("fs");
module.exports = {


  friendlyName: 'Add event',


  description: '',


  inputs: {
    event_name:{
      type:'string',
      description:'event name '
    },
    username:{
      type: 'string',
      example: 'Amit Sharma'
    },
    password:{
       type: 'string',
       description: 'Securely hashed representation of the user\'s login password.',
       example: '2$28a8eabna301089103-13948134nad'
    },
    start_date:{
       type: 'string',
       description: 'start_date',
       ///example: '2$28a8eabna301089103-13948134nad'
    },
    end_date:{
      type:"string",
      description:'end_date'
    },
    frequency:{
      type:'string',
      description:'frequency'
    },
    frequency_type:{
      type:'string',
      description:'frequency_type'
    },
   
    daily_every:{
      type:'string',
      description:'daily_every',
    },
    api_key:{
      type:'string',
      description:'api_key',
    },
    file_name:{
      type:'string',
      description:'file name',
    },
    group:{
      type:'string',
      description:'group name',
    },
    status:{
       type:'string',
       description:'file name'
    },
    url:{
      type:'string',
      description:'url',
    },timeout:{
      type:'string',
      description:'timeout',
    }

  },


  exits: {
    success:{
      status:200,
      message:'Record has been update successfully '
    }
  },


  fn: async function (inputs,exits) {
    var res = this.res;
    var req = this.req;
     var errors=[];
      function validation(string,text){

            if (string.test(text))
                {
                   return true;
                }else{
                   return  false;
                }

        }
      
      if(!inputs.event_name.trim()){
          errors.push('Please enter Event name');
        }
      if(!inputs.url.trim()){
          errors.push('Please enter url');
        }
        if(!inputs.start_date.trim()){
          errors.push('Please enter duration start date');
        }
      if(!inputs.group.trim()){
          errors.push('Please enter group');

      }
      if(!inputs.frequency_type){
        errors.push('Please select  frequency');
         
      }else
      {
        if(inputs.frequency_type==='one_at_time'){

            if(!inputs.frequency.trim()){
              errors.push('Please enter frequency time');
            }
          }
          else if(inputs.frequency_type==='recurring'){

              var resurring=inputs.frequency.split('&')

              console.log(resurring[0])

            if(!resurring[0].trim()){
              errors.push('Please select resurring type');
            }
            if(!resurring[1].trim()){
              errors.push('Please select resurring time');
            }
          }
          else if(inputs.frequency_type==='daily_every'){
            var daily_every= inputs.frequency.split('&');
            if(!daily_every[0].trim()){
              errors.push('Please enter  daily every hours');
            }
            if(!daily_every[1].trim()){
              errors.push('Please enter  daily every minutes');
            }
            if(!daily_every[2].trim()){
              errors.push('Please enter  daily every second');
            }
            if(!daily_every[3].trim()){
              errors.push('Please enter  daily every start time');
            }
            if(!daily_every[4].trim()){
              errors.push('Please enter  daily every end time');
            }
          }
      }
     
      
     
    try{

      if(errors.length===0){
      

              var start_date = new Date(inputs.start_date);
              var end_date = new Date(inputs.end_date);
           if(inputs.frequency_type==='one_at_time'){
                var remaining_count=1/// parseInt(diffDays);
            }else if(inputs.frequency_type==='recurring'){
              var resurring=inputs.frequency.split('&')
              if(resurring[0]==='Daily'){
                  const diffTime = Math.abs(end_date - start_date);
                 const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                 var remaining_count=parseInt(diffDays);
              }
              else if(resurring[0]==='Weekly'){
                  const diffTime = Math.abs(end_date - start_date);
                  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                   var remaining_count=parseInt(diffDays/7);
              
              }else if(resurring[0]==='Monthly'){

                  const diffTime = Math.abs(end_date - start_date);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                var remaining_count =parseInt(diffDays/30);
              }
             
              }else if(inputs.frequency_type==='daily_every'){

                  const diffTime = Math.abs(end_date - start_date);
                 const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                var remaining_count= parseInt(diffDays);
             
              }


              if(inputs.password || inputs.username){
                  
                 var  user= await  User.find({ 'username':inputs.username});
                 if(user.length>0){
                  
                   function passwordCompare(pass1,pass2){
                       return new Promise(function(resolve, reject) {
                        bcrypt.compare(pass1, pass2, function(err, res) {
                            if (err) {
                                 reject(err);
                            } else {
                                 resolve(res);
                            }
                        });
                    });
                  }

                 const password  = await passwordCompare(inputs.password , user[0].password);

                  if(password){

                    data = {
                        
                         event_name:inputs.event_name,
                         duration:inputs.start_date+'&'+inputs.end_date,
                         timeout:inputs.timeout,
                         frequency_type:inputs.frequency_type,
                         frequency:inputs.frequency,
                         api_key:inputs.api_key,
                         url:inputs.url,
                         file:inputs.file_name,
                         group:inputs.group,
                         userid:user[0].id, 
                         remaining_count:remaining_count
                    } 
                     var client = await Event.create(data).fetch();
                      var datasave= {
                          description:inputs.event_name+' Event created Successfully ',
                          actorId:user[0].id,
                          actorType:'Client',
                          actorDisplayName:user[0].fullName,
                          category:'Other'
                        }
                        var save =  await Historylog.create(datasave).fetch();

                        return res.json({record:{
                          status:'success',
                          status_code:200,
                          message:'Event created successfully ',
                          data:data
                        }});

                  }else{
                   

                      return res.json({ record:{
                            status:'error',
                            status_code:202,
                            message:'Invalid Password ',
                      }});
                  }


                 }else{
                 
                  return res.json({record:{ status:'error',status_code:202,message:'Username not found'}})


                 }


              }else{

                data = {
                        
                        event_name:inputs.event_name,
                         duration:inputs.start_date+'&'+inputs.end_date,
                         timeout:inputs.timeout,
                         frequency_type:inputs.frequency_type,
                         frequency:inputs.frequency,
                         api_key:inputs.api_key,
                         url:inputs.url,
                         file:inputs.file_name,
                         group:inputs.group,
                          remaining_count:remaining_count
                         
                          
                    } 
                       await Event.create(data).fetch();
                       var datasave= {
                          description:inputs.event_name+' event created Successfully ',
                          actorId:'4',
                          actorType:'Client',
                          actorDisplayName:'Not found',
                          category:'Other'
                        }
                        var save =  await Historylog.create(datasave).fetch();
                       return res.json({record:{
                          status:'success',
                          status_code:200,
                          message:'Event added successfully ',
                          data:data
                        }});
              }

        

      } else{
        for (var i = 0; i < errors.length; i++) {
                var data= {
                                description:errors[i],
                                actorUserId:0,
                                actorType:"Other",
                                actorDisplayName:"Not Found ",
                                category:'Other'
                          }
                  await Errorlog.create(data).fetch();
                  
              }
        return res.json({record:{status:'error',status_code:203,message:errors}})
      }

    }
    catch(error){
    return res.serverError(error);
      return res.json({record:{
          status:'error',
          status_code:500,message:'Internal Server Error',
      }});
    }
    

  }


};
