module.exports = {


  friendlyName: 'Reset login',


  description: '',


  inputs: {
     password:{
      type:'string',
      //required:true
    },
    

  },


  exits: {
     success:{
      status:'success',
      message:'reset password Successfully  '
    }
  },


  fn: async function (inputs,exits) {

    var res= this.res;
    var req= this.req;

    function validate_password(password){
       var  pass=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        if(pass.test(password)){
          return true;
        }else
        {
          return false;
        }
      }

      try{
           var errors=[];
            
           if(!validate_password(inputs.password))
           {
               msg=' Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special characte';
              errors.push(msg)
           }

           if(errors.length===0){

             var tokan_exits = await  User.find({ password_reset_token:req.param('token')});

             if(tokan_exits.length>0){

               await User.update({'id':tokan_exits[0].id},{password:req.param('password'),password_reset_token:'' });
                      var data= {
                                description:'reset password Successfully ',
                                actorId:tokan_exits[0].id,
                                actorType:'Other',
                                actorDisplayName:tokan_exits[0].fullName,
                                category:'Other'
                              }
                              await Historylog.create(data).fetch();
                              success={
                                status:'success',
                                status_code:200,
                                message:'reset password Successfully  '
                               }

                          return res.json({record:success});
             }else{

                var data= {
                                description:'Token not exits',
                                actorUserId:0,
                                actorType:"Other",
                                actorDisplayName:"Not Found ",
                                category:'Other'
                          }
                  await Historylog.create(data).fetch();
                  return res.json({record:{ status:'error',status_code:202,message:'Token not exits'}})
             }


           }else{

               for (var i = 0; i < errors.length; i++) {
                var data= {
                                description:errors[i],
                                actorUserId:0,
                                actorType:"Other",
                                actorDisplayName:"Not Found ",
                                category:'Other'
                          }
                  await Errorlog.create(data).fetch();
              }
            return res.json({record:{ status:'error',status_code:203,message:errors}})
           }
      }
      catch(error){
        return res.serverError(error)
            /*servereerrro={
              status:'error',
              status_code:500,
              message:'Internal serverError  '
            }
        return res.json({record:servereerrro});*/
      }

  }


};
