module.exports = {


  friendlyName: 'Pause event',


  description: '',


  inputs: {
    id:{
      type:'number',
      description: 'event id '
    }
  },


  exits: {

  },


  fn: async function (inputs) {

      var res= this.res;
      var req= this.req

      try{
       
        var arryTemp = await sails.helpers.getscheduledjobs('All');
        var joblist = sails.config.globals.schedule.scheduledJobs;
        for (let index = 0; index < arryTemp.length; index++) {
          const element = arryTemp[index];          
          if(inputs.id === element.id){
            var my_job = sails.config.globals.schedule.scheduledJobs[element.event_name];
            my_job.cancel();
          }              
        }
        await Event.update({id:inputs.id},{event_status:0, currently_running:0}).fetch();

        return res.json({record:{
          status:"success",
          status_code:200,message:'Event Pause successfully',
        }});

      }catch(error){
         return res.json({record:{
          status:"error",
          status_code:500,message:'Internal Server Error',
         }})

      }

  }


};
