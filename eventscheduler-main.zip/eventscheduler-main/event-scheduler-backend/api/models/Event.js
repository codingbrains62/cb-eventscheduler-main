/**
 * Event.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */
var bcrypt = require('bcrypt-nodejs');
module.exports = {

  attributes: {

    event_name:{
      type:'string',
      description:'event name'
    },

    duration:{
      type:'string',
      description:'duration'
    },
    frequency_type:{
      type:'string',
      description:'reccuing',
    },
    frequency:{
      type:'string',
      description:'one_time_at'
    },
    timeout:{
      type:'string',
      description:'duration'
    },
    api_key:{
      type:'string',
      description:'api_key',
    },
    url:{
      type:'string',
      description:'url ',
    },
    group:{
      type:'string',
      description:'group name',
    },
    file:{
      type:'string',
      description:'file name',
    },
    event_status:{
      type: 'boolean',
      description: 'true= event_status resume false=event_status puase',
      defaultsTo: true
    },
    currently_running:{
      type: 'boolean',
      description: 'true= currently_running ',
      defaultsTo: false
    },
    last_run: {
      type: 'string',
      //columnType: 'datetime'
    },
    next_run: {
      type: 'string',
      //columnType: 'datetime'
    },
    remaining_count :{
      type:'number',
      description:'remaining_count'
    },  repeat:{
      type:'number',
      description:'repeat '
    }, 
    userid:{
      model:'User',
      description:'user id '
    }
    



  },
  customtoJSON:function(){
    return __dirname.omit(this,['password'])
   },beforeCreate: function (user, cb) {


    if (user.password) {
      bcrypt.genSalt(10, function (err, salt) {




        bcrypt.hash(user.password, salt,null, function (err, hash) {
          if (err) {
        ////    console.log(err);
            cb(err);
          } else {
    ////  console.log('bcrypt'+hash)
            user.password = hash;
           ////console.log("saving data" + user.password);
           return cb();
          }
        });
      });
    }else{
     return cb();
    }//
  }

};

