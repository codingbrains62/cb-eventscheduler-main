/**
 * Errorlog.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

 attributes: {



    //  ╔═╗╦═╗╦╔╦╗╦╔╦╗╦╦  ╦╔═╗╔═╗
    //  ╠═╝╠╦╝║║║║║ ║ ║╚╗╔╝║╣ ╚═╗
    //  ╩  ╩╚═╩╩ ╩╩ ╩ ╩ ╚╝ ╚═╝╚═╝

    description: {
      type: 'string',
      required: true,
      description: 'A longer, full-sentence description of the ErrorEvent that occured.'
    },

    actorUserId: {
      type: 'number',
      description: 'This is not an association-- it is another copy of the user id,  in case the user is deleted.'
    },

    actorDisplayName: {
      type: 'string',
      required: true
    },

    category: {
      type: 'string',
      description: 'A special, generic category for this kind of ErrorEvent event.',
      isIn: [
        'System',
        'Database',
        'Email',
        'Auto Document',
        'Other',
      ],
      defaultsTo: 'Other',
    },

    

    //  ╔═╗╔╦╗╔╗ ╔═╗╔╦╗╔═╗
    //  ║╣ ║║║╠╩╗║╣  ║║╚═╗
    //  ╚═╝╩ ╩╚═╝╚═╝═╩╝╚═╝


    //  ╔═╗╔═╗╔═╗╔═╗╔═╗╦╔═╗╔╦╗╦╔═╗╔╗╔╔═╗
    //  ╠═╣╚═╗╚═╗║ ║║  ║╠═╣ ║ ║║ ║║║║╚═╗
    //  ╩ ╩╚═╝╚═╝╚═╝╚═╝╩╩ ╩ ╩ ╩╚═╝╝╚╝╚═╝

    //client: { model: 'Client', description: 'The client this ErrorEventt is related to, if relevant.' },
    

  },

};

